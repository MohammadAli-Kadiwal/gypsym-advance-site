'use client';

import * as React from 'react';
import { Plus, X, Building2, ImageOff, Loader2, Globe, Upload, Link2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { DataTable, ColumnDef } from '@/components/crud/data-table';
import { BaseRecord, ItemStatus } from '@/lib/store';
import { formatDate } from '@/lib/utils';
import { notify } from '@/lib/notifications';
import { fetchApi, normalizeErrorMessage } from '@/lib/api-client';
import { StatusToggleField } from '@/components/crud/status-toggle-field';
import { AdminPageLoadingState } from '@/components/layout/admin-page';

// ─── Types ───────────────────────────────────────────────────────────────────
export interface ClientRecord extends BaseRecord {
  name: string;
  logoUrl?: string | null;
  websiteUrl?: string | null;
  isActive: boolean;
}

interface ClientFormState {
  name: string;
  logoUrl: string;
  websiteUrl: string;
  status: ItemStatus;
}

const EMPTY_FORM: ClientFormState = { name: '', logoUrl: '', websiteUrl: '', status: 'PUBLISHED' };

// ─── Create / Edit Dialog ─────────────────────────────────────────────────────
interface ClientDialogProps {
  open: boolean;
  mode: 'create' | 'edit';
  initial?: ClientFormState;
  saving: boolean;
  onClose: () => void;
  onSubmit: (form: ClientFormState) => void;
}

function ClientDialog({ open, mode, initial = EMPTY_FORM, saving, onClose, onSubmit }: ClientDialogProps) {
  const [form, setForm] = React.useState<ClientFormState>(() => initial);
  const [logoError, setLogoError] = React.useState(false);
  const [tab, setTab] = React.useState<'upload' | 'url'>(() => (initial.logoUrl?.startsWith('http') ? 'url' : 'upload'));
  const [fileName, setFileName] = React.useState<string>('');
  const [fileSize, setFileSize] = React.useState<string>('');
  const [dragActive, setDragActive] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const prevOpenRef = React.useRef(open);
  React.useEffect(() => {
    if (open && !prevOpenRef.current) {
      setForm(initial);
      setLogoError(false);
      setFileName('');
      setFileSize('');
      if (initial.logoUrl?.startsWith('http')) {
        setTab('url');
      } else {
        setTab('upload');
      }
    }
    prevOpenRef.current = open;
  }, [open, initial]);

  function patch(key: keyof ClientFormState, value: any) {
    setForm((f) => ({ ...f, [key]: value }));
    if (key === 'logoUrl') setLogoError(false);
  }

  function handleFileSelect(file: File) {
    if (!file) return;
    if (!file.type.startsWith('image/') && !file.name.endsWith('.svg')) {
      notify.error('Please select a valid image file (SVG, PNG, WebP, JPG).');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      notify.error('Image size exceeds 3MB. Please choose a smaller logo.');
      return;
    }

    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + ' KB');

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        patch('logoUrl', dataUrl);
      }
    };
    reader.readAsDataURL(file);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  }

  function clearLogo() {
    patch('logoUrl', '');
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) {
      notify.error('Client name is required.');
      return;
    }
    onSubmit(form);
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="w-[95vw] max-w-md rounded-2xl border-border bg-card shadow-2xl p-0 overflow-hidden">
        {/* Header */}
        <DialogHeader className="px-6 py-5 border-b border-border/60 bg-muted/20">
          <div className="flex items-center space-x-3.5">
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle className="text-base font-bold text-foreground">
                {mode === 'create' ? 'Add New Client' : 'Edit Client'}
              </DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground mt-0.5">
                {mode === 'create'
                  ? 'Fill in the client details. The logo will appear in the marquee strip on the website.'
                  : 'Update the client name, logo, or website URL.'}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Logo Section */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-foreground">
                Client Logo <span className="text-muted-foreground font-normal">(SVG, PNG, WebP)</span>
              </label>
              {/* Tab Switcher: Direct Upload vs URL */}
              <div className="inline-flex rounded-lg p-0.5 bg-muted border border-border">
                <button
                  type="button"
                  onClick={() => setTab('upload')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                    tab === 'upload'
                      ? 'bg-card text-foreground shadow-xs'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Upload className="h-3 w-3" />
                  Direct Upload
                </button>
                <button
                  type="button"
                  onClick={() => setTab('url')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
                    tab === 'url'
                      ? 'bg-card text-foreground shadow-xs'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Link2 className="h-3 w-3" />
                  Image URL
                </button>
              </div>
            </div>

            {/* Hidden native file input */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/svg+xml,image/png,image/webp,image/jpeg,image/gif"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
              }}
            />

            {/* Direct Upload Mode */}
            {tab === 'upload' ? (
              form.logoUrl ? (
                /* Logo uploaded preview card */
                <div className="flex items-center justify-between p-2.5 sm:p-3 rounded-xl border border-border bg-muted/30">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-12 w-12 rounded-lg bg-card border border-border flex items-center justify-center p-1.5 overflow-hidden shrink-0 shadow-xs">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={form.logoUrl}
                        alt="Logo preview"
                        className="h-full w-full object-contain"
                        onError={() => setLogoError(true)}
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-foreground truncate">
                        {fileName || 'Client Logo Selected'}
                      </p>
                      <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1 mt-0.5">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 inline-block" />
                        Ready to save {fileSize ? `(${fileSize})` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      className="h-7 px-2.5 text-[11px] font-medium rounded-lg cursor-pointer"
                    >
                      Replace
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={clearLogo}
                      className="h-7 w-7 p-0 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 cursor-pointer"
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ) : (
                /* Drag and drop upload zone */
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex flex-col items-center justify-center py-5 px-4 rounded-xl border-2 border-dashed transition-all cursor-pointer text-center ${
                    dragActive
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50 hover:bg-muted/40 bg-card'
                  }`}
                >
                  <div className="h-8 w-8 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-1.5 shadow-2xs">
                    <Upload className="h-4 w-4" />
                  </div>
                  <p className="text-xs font-semibold text-foreground">
                    Click to browse <span className="font-normal text-muted-foreground">or drag &amp; drop logo</span>
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    Supports SVG, PNG, WebP or JPEG (max 3MB)
                  </p>
                </div>
              )
            ) : (
              /* URL Input Mode */
              <div className="space-y-2">
                <div className="flex items-center gap-2.5">
                  <div className="h-10 w-10 rounded-xl border border-border bg-card flex items-center justify-center overflow-hidden shrink-0">
                    {form.logoUrl && !logoError ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={form.logoUrl}
                        alt="Logo preview"
                        className="h-full w-full object-contain p-1"
                        onError={() => setLogoError(true)}
                      />
                    ) : (
                      <ImageOff className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1">
                    <Input
                      value={form.logoUrl}
                      onChange={(e) => patch('logoUrl', e.target.value)}
                      placeholder="https://cdn.example.com/logo.svg"
                      className="text-xs font-mono rounded-xl h-10 bg-background border-input"
                    />
                  </div>
                </div>
                {logoError && (
                  <p className="text-[10px] text-destructive">
                    Could not load image from this URL. Please verify the URL is public and accessible.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Client Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-foreground">
              Client Name <span className="text-destructive">*</span>
            </label>
            <Input
              value={form.name}
              onChange={(e) => patch('name', e.target.value)}
              placeholder="e.g. Apex Cloud Technologies"
              className="h-10 text-xs rounded-xl border-input bg-background"
              autoFocus
            />
          </div>

          {/* Website URL */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-foreground flex items-center space-x-1.5">
              <Globe className="h-3 w-3" />
              <span>
                Website URL <span className="text-muted-foreground font-normal">(optional)</span>
              </span>
            </label>
            <Input
              value={form.websiteUrl}
              onChange={(e) => patch('websiteUrl', e.target.value)}
              placeholder="https://apexcloud.com"
              className="h-10 text-xs font-mono rounded-xl border-input bg-background"
            />
          </div>

          {/* Publication Status: Draft vs Public */}
          <StatusToggleField
            value={form.status}
            onChange={(status) => patch('status', status)}
          />

          {/* Footer Actions */}
          <DialogFooter className="pt-4 border-t border-border/60 gap-2 flex-row justify-end items-center">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="rounded-xl h-9 px-4 text-xs font-medium cursor-pointer"
            >
              <X className="h-3.5 w-3.5 mr-1.5" />
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving || !form.name.trim()}
              className="rounded-xl h-9 px-5 text-xs font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-xs cursor-pointer"
            >
              {saving ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                  Saving…
                </>
              ) : (
                <>
                  <Plus className="h-3.5 w-3.5 mr-1.5" />
                  {mode === 'create' ? 'Create Client' : 'Update Client'}
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Clients Page ────────────────────────────────────────────────────────
export default function ClientsPage() {
  const [mounted, setMounted] = React.useState(false);
  const [clients, setClients] = React.useState<ClientRecord[]>([]);
  const [saving, setSaving] = React.useState(false);

  const [createOpen, setCreateOpen] = React.useState(false);
  const [editOpen, setEditOpen] = React.useState(false);
  const [editTarget, setEditTarget] = React.useState<ClientRecord | null>(null);

  // ── Fetch ──────────────────────────────────────────────────────────────────
  const loadClients = React.useCallback(async () => {
    try {
      const data = await fetchApi<ClientRecord[]>('/clients');
      setClients(
        Array.isArray(data)
          ? data.map((c) => ({
              ...c,
              status: (c.status || (c.isActive ? 'PUBLISHED' : 'DRAFT')) as ItemStatus,
            }))
          : []
      );
    } catch {
      setClients([]);
    }
  }, []);

  React.useEffect(() => {
    setMounted(true);
    loadClients();
  }, [loadClients]);

  // ── Create ─────────────────────────────────────────────────────────────────
  async function handleCreate(form: ClientFormState) {
    setSaving(true);
    try {
      const created = await fetchApi<ClientRecord>('/clients', {
        method: 'POST',
        body: JSON.stringify({
          name: form.name.trim(),
          logoUrl: form.logoUrl.trim() || null,
          websiteUrl: form.websiteUrl.trim() || null,
          status: form.status,
          isActive: form.status === 'PUBLISHED',
        }),
      });
      const resolvedStatus = (created.status || form.status) as ItemStatus;
      setClients((prev) => [
        { ...created, status: resolvedStatus, isActive: resolvedStatus === 'PUBLISHED' },
        ...prev,
      ]);
      setCreateOpen(false);
      notify.success(`Client "${created.name}" created successfully.`);
    } catch (err: any) {
      notify.error(normalizeErrorMessage(err) || 'Could not create client. Please check your input and try again.');
    } finally {
      setSaving(false);
    }
  }

  // ── Close Edit ─────────────────────────────────────────────────────────────
  function handleCloseEdit() {
    setEditOpen(false);
    // Keep editTarget during exit transition so form fields do not flash blank while animating out
    setTimeout(() => {
      setEditTarget(null);
    }, 300);
  }

  // ── Update ─────────────────────────────────────────────────────────────────
  async function handleUpdate(form: ClientFormState) {
    if (!editTarget) return;
    const targetId = editTarget.id;
    const clientName = form.name.trim();
    const clientLogoUrl = form.logoUrl.trim() || null;
    const clientWebsiteUrl = form.websiteUrl.trim() || null;
    const clientStatus = form.status;
    const isActive = clientStatus === 'PUBLISHED';

    setSaving(true);

    // 1. Instantly update the client in local state so the front-end table NEVER loses the value
    setClients((prev) =>
      prev.map((c) =>
        c.id === targetId
          ? {
              ...c,
              name: clientName,
              logoUrl: clientLogoUrl || c.logoUrl,
              websiteUrl: clientWebsiteUrl,
              status: clientStatus,
              isActive,
            }
          : c
      )
    );

    try {
      const raw = await fetchApi<any>(`/clients/${targetId}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: clientName,
          logoUrl: clientLogoUrl,
          websiteUrl: clientWebsiteUrl,
          status: clientStatus,
          isActive,
        }),
      });

      const updated = (raw && typeof raw === 'object' && 'data' in raw) ? raw.data : (raw || {});
      const resolvedStatus = (updated.status || clientStatus) as ItemStatus;

      // 2. Merge server-confirmed response fields
      setClients((prev) =>
        prev.map((c) =>
          c.id === targetId
            ? {
                ...c,
                ...updated,
                name: updated.name || clientName,
                logoUrl: updated.logoUrl ?? clientLogoUrl ?? c.logoUrl,
                websiteUrl: updated.websiteUrl ?? clientWebsiteUrl,
                status: resolvedStatus,
                isActive: resolvedStatus === 'PUBLISHED',
              }
            : c
        )
      );

      handleCloseEdit();
      notify.success(`Client "${clientName}" updated.`);

      // 3. Re-verify with API in background
      loadClients().catch(() => {});
    } catch (err: any) {
      notify.error(normalizeErrorMessage(err) || 'Could not update client. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  // ── Delete ─────────────────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    setClients((prev) => prev.filter((c) => c.id !== id));
    await fetchApi(`/clients/${id}`, { method: 'DELETE' });
    loadClients().catch(() => {});
  }

  // ── Bulk Delete ─────────────────────────────────────────────────────────────
  async function handleBulkDelete(ids: string[]) {
    setClients((prev) => prev.filter((c) => !ids.includes(c.id)));
    await fetchApi('/clients/bulk-delete', {
      method: 'POST',
      body: JSON.stringify({ ids }),
    });
    loadClients().catch(() => {});
  }

  // ── Bulk Status Change ──────────────────────────────────────────────────────
  async function handleBulkStatus(ids: string[], status: ItemStatus) {
    const isActive = status === 'PUBLISHED';
    setClients((prev) =>
      prev.map((c) => (ids.includes(c.id) ? { ...c, status, isActive } : c))
    );
    await fetchApi('/clients/bulk-status', {
      method: 'PUT',
      body: JSON.stringify({ ids, status }),
    });
    loadClients().catch(() => {});
  }

  const columns: ColumnDef<ClientRecord>[] = [
    {
      key: 'logo',
      header: 'Logo',
      render: (item) => (
        <div className="h-9 w-9 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
          {item.logoUrl ? (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img
              src={item.logoUrl}
              alt={item.name}
              className="h-full w-full object-contain p-1"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
          ) : (
            <Building2 className="h-4 w-4 text-slate-300" />
          )}
        </div>
      ),
    },
    {
      key: 'name',
      header: 'Client Name',
      sortable: true,
      render: (item) => (
        <div>
          <span className="font-semibold text-slate-900 text-xs">{item.name}</span>
          {item.websiteUrl && (
            <a
              href={item.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[11px] text-blue-600 hover:underline flex items-center gap-1 mt-0.5"
              onClick={(e) => e.stopPropagation()}
            >
              <span className="truncate max-w-[220px]">{item.websiteUrl}</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          )}
        </div>
      ),
    },
    {
      key: 'websiteUrl',
      header: 'Website',
      render: (item) =>
        item.websiteUrl ? (
          <a
            href={item.websiteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-700 font-medium hover:underline"
            onClick={(e) => e.stopPropagation()}
          >
            <Globe className="h-3.5 w-3.5 text-slate-400" />
            <span className="truncate max-w-[180px]">{item.websiteUrl.replace(/^https?:\/\//, '')}</span>
          </a>
        ) : (
          <span className="text-slate-300 font-mono text-xs">—</span>
        ),
    },
    {
      key: 'createdAt',
      header: 'Created',
      sortable: true,
      render: (item) => (
        <span className="font-mono text-[11px] text-slate-500">
          {item.createdAt ? formatDate(item.createdAt) : '—'}
        </span>
      ),
    },
  ];

  if (!mounted) {
    return (
      <AdminPageLoadingState
        title="Clients"
        message="Loading client logos, marquee strips, and enterprise references..."
        description="Syncing state with Gypsym platform services..."
        variant="wide"
      />
    );
  }

  return (
    <>
      <DataTable<ClientRecord>
        title="Clients"
        description="Manage client logos and names used in marquee strips and across the website."
        data={clients}
        columns={columns}
        searchKeys={['name', 'websiteUrl']}
        requiredPermission="content:write"
        addButtonLabel="Add Client"
        entityName="client"
        emptyStateTitle="No clients yet."
        emptyStateDescription="Add your first client to start populating the marquee strip."
        onAdd={() => {
          setCreateOpen(true);
        }}
        onEdit={(item) => {
          setEditTarget(item);
          setEditOpen(true);
        }}
        onDelete={handleDelete}
        onBulkDelete={handleBulkDelete}
        onBulkStatusChange={handleBulkStatus}
      />

      {/* ── Dialogs ────────────────────────────────────────────────────────── */}
      <ClientDialog
        key={createOpen ? 'create-client' : 'create-closed'}
        open={createOpen}
        mode="create"
        saving={saving}
        onClose={() => setCreateOpen(false)}
        onSubmit={handleCreate}
      />

      <ClientDialog
        key={editTarget?.id || 'edit-client'}
        open={editOpen}
        mode="edit"
        initial={
          editTarget
            ? {
                name: editTarget.name,
                logoUrl: editTarget.logoUrl || '',
                websiteUrl: editTarget.websiteUrl || '',
                status: (editTarget.status || (editTarget.isActive ? 'PUBLISHED' : 'DRAFT')) as ItemStatus,
              }
            : EMPTY_FORM
        }
        saving={saving}
        onClose={handleCloseEdit}
        onSubmit={handleUpdate}
      />
    </>
  );
}
