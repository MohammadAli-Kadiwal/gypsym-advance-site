'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { fetchApi } from '@/lib/api-client';
import { notify } from '@/lib/notifications';
import {
  Inbox,
  Search,
  Mail,
  Building2,
  Calendar,
  ExternalLink,
  Trash2,
  Eye,
  X,
  RefreshCw,
  Archive,
  UserCheck,
  CheckCheck,
  Printer,
} from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { ConfirmDialog } from '@/components/crud/confirm-dialog';
import { AdminContentContainer, AdminPageHeader, AdminLoadingState } from '@/components/layout/admin-page';
import { TablePagination } from '@/components/ui/table-pagination';
import { ExecutiveBriefingDossier, type BriefingData } from '@/components/briefing/executive-briefing-dossier';

interface SubmissionItem {
  id: string;
  fullName: string;
  businessEmail: string;
  phone?: string | null;
  companyName?: string | null;
  projectDescription?: string | null;
  formId?: string | null;
  source?: string | null;
  submittedData?: Record<string, any>;
  status: 'NEW' | 'QUALIFIED' | 'ASSIGNED' | 'CONTACTED' | 'OPPORTUNITY' | 'DISQUALIFIED' | 'READ' | 'ARCHIVED';
  ipAddress?: string | null;
  utmSource?: string | null;
  utmMedium?: string | null;
  utmCampaign?: string | null;
  createdAt: string;
  updatedAt: string;
}

const STATUS_CONFIG: Record<string, { label: string; badgeClass: string }> = {
  NEW: { label: 'New', badgeClass: 'bg-blue-50 text-blue-700 border-blue-200' },
  READ: { label: 'Read', badgeClass: 'bg-slate-100 text-slate-700 border-slate-200' },
  CONTACTED: { label: 'Contacted', badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  QUALIFIED: { label: 'Qualified', badgeClass: 'bg-purple-50 text-purple-700 border-purple-200' },
  ASSIGNED: { label: 'Assigned', badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
  OPPORTUNITY: { label: 'Opportunity', badgeClass: 'bg-amber-50 text-amber-700 border-amber-200' },
  DISQUALIFIED: { label: 'Disqualified', badgeClass: 'bg-rose-50 text-rose-700 border-rose-200' },
  ARCHIVED: { label: 'Archived', badgeClass: 'bg-slate-100 text-slate-500 border-slate-200' },
};

export default function ContactSubmissionsPage() {
  const [items, setItems] = React.useState<SubmissionItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState('');
  const [statusFilter, setStatusFilter] = React.useState<string>('ALL');
  const [page, setPage] = React.useState(1);
  const [pageSize, setPageSize] = React.useState(10);
  const [selectedSubmission, setSelectedSubmission] = React.useState<SubmissionItem | null>(null);
  const [totalCount, setTotalCount] = React.useState(0);
  const [selectedIds, setSelectedIds] = React.useState<Set<string>>(new Set());
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = React.useState(false);
  const [isBulkProcessing, setIsBulkProcessing] = React.useState(false);
  const [deleteSubmissionId, setDeleteSubmissionId] = React.useState<string | null>(null);
  const [dossierTarget, setDossierTarget] = React.useState<BriefingData | null>(null);

  const loadSubmissions = React.useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set('search', search.trim());
      if (statusFilter !== 'ALL') params.set('status', statusFilter);
      params.set('page', page.toString());
      params.set('limit', pageSize.toString());

      const res = await fetchApi<{ items: SubmissionItem[]; total: number }>(`/inquiries?${params.toString()}`);
      if (res && Array.isArray(res.items)) {
        setItems(res.items);
        setTotalCount(res.total);
      }
    } catch {
      notify.error('Unable to load contact submissions.');
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter, page, pageSize]);

  React.useEffect(() => {
    loadSubmissions();
  }, [loadSubmissions]);

  // Escape key listener to dismiss centered modal popup
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && selectedSubmission) {
        setSelectedSubmission(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSubmission]);

  // Status transition
  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      const updated = await fetchApi<SubmissionItem>(`/inquiries/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus }),
      });

      setItems((prev) => prev.map((item) => (item.id === id ? { ...item, status: updated.status } : item)));
      if (selectedSubmission?.id === id) {
        setSelectedSubmission((prev) => (prev ? { ...prev, status: updated.status } : null));
      }
      notify.success(`Status updated to ${STATUS_CONFIG[newStatus]?.label || newStatus}.`);
    } catch {
      notify.error('Unable to update submission status.');
    }
  };

  // Delete submission (using popup confirmation dialog instead of browser alert)
  const handleDelete = (id: string) => {
    setDeleteSubmissionId(id);
  };

  const confirmSingleDeleteSubmission = async () => {
    if (!deleteSubmissionId) return;
    try {
      await fetchApi(`/inquiries/${deleteSubmissionId}`, { method: 'DELETE' });
      setItems((prev) => prev.filter((item) => item.id !== deleteSubmissionId));
      if (selectedSubmission?.id === deleteSubmissionId) {
        setSelectedSubmission(null);
      }
      notify.success('Submission record deleted.');
      setDeleteSubmissionId(null);
    } catch {
      notify.error('Unable to delete submission.');
    }
  };

  // Open detail and auto-mark NEW as READ
  const handleOpenDetail = (sub: SubmissionItem) => {
    setSelectedSubmission(sub);
    if (sub.status === 'NEW') {
      handleUpdateStatus(sub.id, 'READ');
    }
  };

  // ── Bulk Selection & Actions ─────────────────────────────────────────────
  const isAllSelected = items.length > 0 && items.every((i) => selectedIds.has(i.id));

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(new Set(items.map((i) => i.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  const handleToggleSelect = (id: string, checked: boolean) => {
    const next = new Set(selectedIds);
    if (checked) {
      next.add(id);
    } else {
      next.delete(id);
    }
    setSelectedIds(next);
  };

  const handleBulkStatus = async (status: string) => {
    if (selectedIds.size === 0) return;
    setIsBulkProcessing(true);
    const ids = Array.from(selectedIds);
    try {
      await Promise.all(
        ids.map((id) =>
          fetchApi(`/inquiries/${id}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status }),
          })
        )
      );
      setItems((prev) =>
        prev.map((item) => (selectedIds.has(item.id) ? { ...item, status: status as any } : item))
      );
      if (selectedSubmission && selectedIds.has(selectedSubmission.id)) {
        setSelectedSubmission((prev) => (prev ? { ...prev, status: status as any } : null));
      }
      setSelectedIds(new Set());
      notify.success(`${ids.length} submissions marked as ${STATUS_CONFIG[status]?.label || status}.`);
    } catch {
      notify.error('Failed to update status for selected submissions.');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;
    setIsBulkProcessing(true);
    const ids = Array.from(selectedIds);
    try {
      await fetchApi('/inquiries/bulk-delete', {
        method: 'POST',
        body: JSON.stringify({ ids }),
      });
      setItems((prev) => prev.filter((item) => !selectedIds.has(item.id)));
      setTotalCount((c) => Math.max(0, c - ids.length));
      if (selectedSubmission && selectedIds.has(selectedSubmission.id)) {
        setSelectedSubmission(null);
      }
      setSelectedIds(new Set());
      setBulkDeleteConfirm(false);
      notify.success(`${ids.length} submissions deleted.`);
    } catch {
      notify.error('Failed to delete selected submissions.');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  return (
    <AdminContentContainer variant="wide">
      {/* ── Unified Admin Page Header ────────────────────────────────────────── */}
      <AdminPageHeader
        title={
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Mail className="h-4 w-4" />
            </div>
            <span>Contact Submissions</span>
          </div>
        }
        status={
          <Badge variant="outline" className="text-xs font-mono bg-primary/5 text-primary border-primary/20">
            {totalCount} Total Inquiries
          </Badge>
        }
        description="Enterprise leads, inquiries, and inbound messages captured via homepage contact forms."
        actions={
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={loadSubmissions}
            className="gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-muted-foreground ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        }
      />

      {/* ── Filter Bar ────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by full name, email, or company..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="pl-9 h-9 text-xs rounded-xl border-border bg-card"
          />
        </div>

        {/* Status Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {['ALL', 'NEW', 'READ', 'CONTACTED', 'ARCHIVED'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => {
                setStatusFilter(st);
                setPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                statusFilter === st
                  ? 'bg-primary text-primary-foreground shadow-2xs'
                  : 'bg-card text-muted-foreground border border-border hover:bg-muted'
              }`}
            >
              {st === 'ALL' ? 'All' : STATUS_CONFIG[st]?.label || st}
            </button>
          ))}
        </div>
      </div>

      {/* ── Submissions Table ─────────────────────────────────────────────── */}
      <Card className="rounded-2xl border-border shadow-xs bg-card overflow-hidden">
        <CardContent className="p-0">
          {loading ? (
            <AdminLoadingState
              title="Loading Contact Inquiries"
              message="Fetching incoming lead submissions from Gypsym cluster..."
              className="border-0 shadow-none bg-transparent py-20"
            />
          ) : items.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="h-12 w-12 rounded-2xl bg-muted text-muted-foreground flex items-center justify-center mx-auto">
                <Inbox className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-foreground">No contact submissions found</p>
                <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                  {search ? 'Try adjusting your search keywords or status filter.' : 'Inbound inquiries from the homepage contact form will appear here.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-border bg-muted/40 text-muted-foreground uppercase tracking-wider font-semibold text-[10px]">
                    <th className="py-3 px-3 w-10 text-center">
                      <Checkbox
                        checked={isAllSelected}
                        onCheckedChange={(c) => handleSelectAll(!!c)}
                        aria-label="Select all"
                      />
                    </th>
                    <th className="py-3 px-4">Contact</th>
                    <th className="py-3 px-4">Company</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Source</th>
                    <th className="py-3 px-4">Received</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {items.map((sub) => {
                    const stConf = STATUS_CONFIG[sub.status] ?? {
                      label: sub.status,
                      badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
                    };
                    return (
                      <tr
                        key={sub.id}
                        onClick={() => handleOpenDetail(sub)}
                        className={`hover:bg-slate-50/80 cursor-pointer transition-colors ${
                          selectedIds.has(sub.id)
                            ? 'bg-blue-50/40'
                            : sub.status === 'NEW'
                            ? 'bg-blue-50/30 font-medium'
                            : ''
                        }`}
                      >
                        <td className="py-3 px-3 w-10 text-center" onClick={(e) => e.stopPropagation()}>
                          <Checkbox
                            checked={selectedIds.has(sub.id)}
                            onCheckedChange={(c) => handleToggleSelect(sub.id, !!c)}
                            aria-label={`Select ${sub.fullName}`}
                          />
                        </td>
                        <td className="py-3 px-4">
                          <div className="space-y-0.5">
                            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                              {sub.fullName}
                              {sub.status === 'NEW' && (
                                <span className="inline-block w-2 h-2 rounded-full bg-blue-600" />
                              )}
                            </div>
                            <div className="text-slate-500 flex items-center gap-1 text-[11px]">
                              <Mail className="w-3 h-3" />
                              <span>{sub.businessEmail}</span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4 text-slate-700">
                          {sub.companyName ? (
                            <div className="flex items-center gap-1">
                              <Building2 className="w-3 h-3 text-slate-400" />
                              <span>{sub.companyName}</span>
                            </div>
                          ) : (
                            <span className="text-slate-400 italic">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          <Badge variant="outline" className={`text-[10px] font-semibold ${stConf.badgeClass}`}>
                            {stConf.label}
                          </Badge>
                        </td>

                        <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                          {sub.source || 'Homepage'}
                        </td>

                        <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                          {new Date(sub.createdAt).toLocaleDateString('en-GB', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </td>

                        <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setDossierTarget({
                                  clientName: sub.fullName,
                                  email: sub.businessEmail,
                                  phone: sub.phone,
                                  company: sub.companyName,
                                  inquiryMessage: sub.projectDescription,
                                  source: sub.source,
                                  status: sub.status,
                                });
                              }}
                              className="h-8 w-8 p-0 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted cursor-pointer"
                              title="1-Click Executive Dossier (PDF / Print)"
                            >
                              <Printer className="w-3.5 h-3.5 text-primary" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDetail(sub)}
                              className="h-8 w-8 p-0 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted cursor-pointer"
                              title="View Details"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(sub.id)}
                              className="h-8 w-8 p-0 rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                              title="Delete Submission"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {!loading && totalCount > 0 && (
            <TablePagination
              currentPage={page}
              totalItems={totalCount}
              pageSize={pageSize}
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
              itemLabel="submissions"
            />
          )}
        </CardContent>
      </Card>

      {/* ── Floating Bulk Action Dock ───────────────────────────────────────── */}
      {selectedIds.size > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center space-x-2.5 rounded-2xl border border-slate-200 bg-white/95 px-5 py-2.5 shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-3 duration-200">
          <span className="text-xs font-semibold text-slate-800 pr-2 border-r border-slate-200">
            {selectedIds.size} selected
          </span>

          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs rounded-xl border-slate-200 hover:bg-slate-100"
            onClick={() => handleBulkStatus('READ')}
          >
            <CheckCheck className="h-3.5 w-3.5 mr-1 text-slate-600" />
            <span>Mark Read</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs rounded-xl border-slate-200 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200"
            onClick={() => handleBulkStatus('CONTACTED')}
          >
            <UserCheck className="h-3.5 w-3.5 mr-1 text-emerald-600" />
            <span>Contacted</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs rounded-xl border-slate-200 hover:bg-slate-100"
            onClick={() => handleBulkStatus('ARCHIVED')}
          >
            <Archive className="h-3.5 w-3.5 mr-1 text-slate-500" />
            <span>Archive</span>
          </Button>

          <Button
            variant="destructive"
            size="sm"
            className="h-8 text-xs rounded-xl bg-rose-600 hover:bg-rose-700"
            onClick={() => setBulkDeleteConfirm(true)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1" />
            <span>Delete</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-xs text-slate-400 hover:text-slate-600 rounded-xl ml-1"
            onClick={() => setSelectedIds(new Set())}
          >
            Clear
          </Button>
        </div>
      )}

      {/* ── Bulk Delete Confirmation Dialog ─────────────────────────────────── */}
      <ConfirmDialog
        open={bulkDeleteConfirm}
        onOpenChange={(open) => !open && setBulkDeleteConfirm(false)}
        title={`Delete ${selectedIds.size} Submissions?`}
        description={`Are you sure you want to delete ${selectedIds.size} selected contact submissions? This action cannot be undone.`}
        confirmLabel={isBulkProcessing ? 'Deleting...' : `Delete ${selectedIds.size} Submissions`}
        variant="destructive"
        onConfirm={handleBulkDelete}
      />

      {/* ── Centered Responsive Detail Modal Popup ──────────────────────────── */}
      {selectedSubmission && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setSelectedSubmission(null)}
        >
          <div
            className="w-full max-w-2xl max-h-[90vh] bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200/90 flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-5 py-4 sm:px-6 sm:py-5 border-b border-slate-100 flex items-start justify-between gap-4 bg-slate-50/70 shrink-0">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                    {selectedSubmission.fullName}
                  </h3>
                  <Badge
                    variant="outline"
                    className={`text-[10px] font-semibold ${
                      STATUS_CONFIG[selectedSubmission.status]?.badgeClass || ''
                    }`}
                  >
                    {STATUS_CONFIG[selectedSubmission.status]?.label || selectedSubmission.status}
                  </Badge>
                </div>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Submitted on {new Date(selectedSubmission.createdAt).toLocaleString('en-GB')}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedSubmission(null)}
                className="h-8 w-8 rounded-xl border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1">
              {/* Quick Status Bar */}
              <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <span className="text-xs font-semibold text-slate-600">Update Status:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Button
                    type="button"
                    size="sm"
                    variant={selectedSubmission.status === 'CONTACTED' ? 'default' : 'outline'}
                    onClick={() => handleUpdateStatus(selectedSubmission.id, 'CONTACTED')}
                    className="h-7 px-2.5 text-[11px] rounded-lg gap-1 font-semibold"
                  >
                    <UserCheck className="w-3 h-3" />
                    Contacted
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={selectedSubmission.status === 'QUALIFIED' ? 'default' : 'outline'}
                    onClick={() => handleUpdateStatus(selectedSubmission.id, 'QUALIFIED')}
                    className="h-7 px-2.5 text-[11px] rounded-lg gap-1 font-semibold"
                  >
                    <CheckCheck className="w-3 h-3" />
                    Qualified
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={selectedSubmission.status === 'ARCHIVED' ? 'default' : 'outline'}
                    onClick={() => handleUpdateStatus(selectedSubmission.id, 'ARCHIVED')}
                    className="h-7 px-2.5 text-[11px] rounded-lg gap-1 font-semibold"
                  >
                    <Archive className="w-3 h-3" />
                    Archive
                  </Button>
                </div>
              </div>

              {/* Contact Information */}
              <div className="space-y-2.5">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Contact Details
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3.5 sm:p-4 bg-slate-50/50 rounded-xl border border-slate-100 text-xs">
                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Email Address</span>
                    <a
                      href={`mailto:${selectedSubmission.businessEmail}`}
                      className="text-blue-600 font-semibold hover:underline inline-flex items-center gap-1 mt-0.5 break-all"
                    >
                      {selectedSubmission.businessEmail}
                      <ExternalLink className="w-3 h-3 shrink-0" />
                    </a>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Phone Number</span>
                    <span className="text-slate-800 font-medium block mt-0.5">
                      {selectedSubmission.phone || '—'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Company Organization</span>
                    <span className="text-slate-800 font-medium block mt-0.5">
                      {selectedSubmission.companyName || '—'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block font-medium">Form Identifier</span>
                    <span className="text-slate-800 font-mono text-[11px] block mt-0.5">
                      {selectedSubmission.formId || 'homepage-contact'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Dynamic Submitted Form Fields */}
              <div className="space-y-2.5">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Submitted Form Data
                </h4>
                {selectedSubmission.submittedData && Object.keys(selectedSubmission.submittedData).length > 0 ? (
                  <div className="border border-slate-100 rounded-xl overflow-hidden divide-y divide-slate-100">
                    {Object.entries(selectedSubmission.submittedData).map(([key, val]) => (
                      <div key={key} className="p-3 bg-white flex flex-col sm:flex-row sm:items-start justify-between gap-1.5 text-xs">
                        <span className="font-semibold text-slate-600 capitalize sm:w-1/3 shrink-0">
                          {key.replace(/([A-Z])/g, ' $1').trim()}:
                        </span>
                        <span className="text-slate-900 sm:w-2/3 whitespace-pre-wrap break-words">
                          {typeof val === 'object' ? JSON.stringify(val, null, 2) : String(val)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No additional dynamic fields provided.</p>
                )}
              </div>

              {/* Project Description / Message if specified */}
              {selectedSubmission.projectDescription && (
                <div className="space-y-2">
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Message / Project Scope
                  </h4>
                  <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-100 text-xs text-slate-800 leading-relaxed whitespace-pre-line">
                    {selectedSubmission.projectDescription}
                  </div>
                </div>
              )}

              {/* Technical Tracking Context */}
              <div className="space-y-2">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Technical Metadata
                </h4>
                <div className="p-3 bg-slate-50/40 rounded-xl border border-slate-100 font-mono text-[11px] text-slate-500 space-y-1">
                  <div><strong>IP Address:</strong> {selectedSubmission.ipAddress || 'unknown'}</div>
                  {selectedSubmission.utmSource && <div><strong>UTM Source:</strong> {selectedSubmission.utmSource}</div>}
                  {selectedSubmission.utmMedium && <div><strong>UTM Medium:</strong> {selectedSubmission.utmMedium}</div>}
                  {selectedSubmission.utmCampaign && <div><strong>UTM Campaign:</strong> {selectedSubmission.utmCampaign}</div>}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3.5 sm:px-6 sm:py-4 border-t border-slate-100 bg-slate-50/70 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shrink-0">
              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleDelete(selectedSubmission.id)}
                  className="rounded-xl h-9 text-xs font-semibold text-rose-600 border-rose-200 hover:bg-rose-50 gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete Submission
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setDossierTarget({
                      clientName: selectedSubmission.fullName,
                      email: selectedSubmission.businessEmail,
                      phone: selectedSubmission.phone,
                      company: selectedSubmission.companyName,
                      inquiryMessage: selectedSubmission.projectDescription,
                      source: selectedSubmission.source,
                      status: selectedSubmission.status,
                    });
                  }}
                  className="rounded-xl h-9 text-xs font-semibold gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-primary" />
                  <span>Dossier (PDF)</span>
                </Button>
              </div>

              <div className="flex items-center gap-2 justify-end">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedSubmission(null)}
                  className="rounded-xl h-9 text-xs font-medium text-muted-foreground hover:text-foreground cursor-pointer"
                >
                  Close
                </Button>

                <a
                  href={`mailto:${selectedSubmission.businessEmail}?subject=Re: Enterprise Inquiry - Gypsym Technology`}
                  className="inline-flex items-center justify-center gap-1.5 px-4 h-9 rounded-xl text-xs font-semibold bg-primary hover:bg-primary/90 text-primary-foreground shadow-xs cursor-pointer"
                >
                  <Mail className="w-3.5 h-3.5" />
                  Reply via Email
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── 1-Click Executive PDF Briefing Dossier Modal ──────────── */}
      <ExecutiveBriefingDossier
        open={Boolean(dossierTarget)}
        onOpenChange={(open) => {
          if (!open) setDossierTarget(null);
        }}
        data={dossierTarget}
      />

      {/* ── Single Submission Delete Confirm Dialog ──────────── */}
      <ConfirmDialog
        open={Boolean(deleteSubmissionId)}
        onOpenChange={(open) => {
          if (!open) setDeleteSubmissionId(null);
        }}
        title="Delete Submission Record?"
        description="Are you sure you want to permanently delete this contact inquiry record? This action cannot be undone."
        confirmLabel="Delete Record"
        variant="destructive"
        onConfirm={confirmSingleDeleteSubmission}
      />
    </AdminContentContainer>
  );
}
