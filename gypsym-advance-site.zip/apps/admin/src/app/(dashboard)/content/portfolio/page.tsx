'use client';

import * as React from 'react';
import {
  Briefcase,
  FolderTree,
  ExternalLink,
  Upload,
  Link2,
  ImageOff,
  Loader2,
  X,
  MessageSquare,
  Megaphone,
  SlidersHorizontal,
  Calendar,
} from 'lucide-react';
import { DataTable, ColumnDef } from '@/components/crud/data-table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { RichTextEditor } from '@/components/ui/rich-text-editor';
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { formatDate, formatDateDDMMYYYY, cn } from '@/lib/utils';
import { fetchApi, normalizeErrorMessage } from '@/lib/api-client';
import { notify } from '@/lib/notifications';
import { BaseRecord, ItemStatus } from '@/lib/store';
import { AdminContentContainer, AdminPageHeader } from '@/components/layout/admin-page';
import { StatusToggleField } from '@/components/crud/status-toggle-field';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface PortfolioProjectRecord extends BaseRecord {
  orderNumber?: string;
  title: string;
  slug: string;
  client?: string;
  category?: string;
  categorySlug?: string;
  categoryId?: string;
  description?: string;
  imageUrl: string;
  altText?: string;
  projectUrl?: string;
  tags?: string[];
  metrics?: string;
  displayOrder?: number;
  projectDate?: string;
}

export interface PortfolioCategoryRecord extends BaseRecord {
  name: string;
  slug: string;
  description?: string;
  displayOrder?: number;
  projectCount?: number;
}

interface ProjectFormState {
  orderNumber: string;
  title: string;
  slug: string;
  client: string;
  categoryId: string;
  projectDate: string;
  metrics: string;
  projectUrl: string;
  imageUrl: string;
  description: string;
  tagsString: string;
  status: string;
  showOnHomepage: boolean;
}

const EMPTY_PROJECT_FORM: ProjectFormState = {
  orderNumber: '',
  title: '',
  slug: '',
  client: '',
  categoryId: '',
  projectDate: (new Date().toISOString().split('T')[0]) ?? '',
  metrics: '',
  projectUrl: '',
  imageUrl: '',
  description: '',
  tagsString: '',
  status: 'PUBLISHED',
  showOnHomepage: true,
};

interface CategoryFormState {
  name: string;
  slug: string;
  displayOrder: string;
  description: string;
  status: string;
}

const EMPTY_CATEGORY_FORM: CategoryFormState = {
  name: '',
  slug: '',
  displayOrder: '1',
  description: '',
  status: 'PUBLISHED',
};

// ─── Project Popup Modal (Client-Style Popup with Direct Image Upload) ────────

interface ProjectDialogProps {
  open: boolean;
  mode: 'create' | 'edit';
  initial?: PortfolioProjectRecord | null;
  categories: PortfolioCategoryRecord[];
  saving: boolean;
  isFeaturedOnHome?: boolean;
  onClose: () => void;
  onSubmit: (form: Record<string, any>, showOnHomepage: boolean) => void;
}

function getInitialProjectForm(
  initial?: PortfolioProjectRecord | null,
  isFeaturedOnHome: boolean = true
): ProjectFormState {
  if (!initial) return { ...EMPTY_PROJECT_FORM, showOnHomepage: isFeaturedOnHome };
  const initialDate = (initial.projectDate
    ? String(initial.projectDate).split('T')[0]
    : initial.createdAt
    ? String(initial.createdAt).split('T')[0]
    : new Date().toISOString().split('T')[0]) ?? '';

  return {
    orderNumber: initial.orderNumber || '',
    title: initial.title || '',
    slug: initial.slug || '',
    client: initial.client || '',
    categoryId: initial.categoryId || '',
    projectDate: initialDate,
    metrics: initial.metrics || '',
    projectUrl: initial.projectUrl || '',
    imageUrl: initial.imageUrl || '',
    description: initial.description || '',
    tagsString: Array.isArray(initial.tags) ? initial.tags.join(', ') : '',
    status: (initial.status as string) || 'PUBLISHED',
    showOnHomepage: isFeaturedOnHome,
  };
}

function ProjectDialog({
  open,
  mode,
  initial,
  categories,
  saving,
  isFeaturedOnHome = true,
  onClose,
  onSubmit,
}: ProjectDialogProps) {
  const [form, setForm] = React.useState<ProjectFormState>(() =>
    getInitialProjectForm(initial, isFeaturedOnHome)
  );
  const [imageTab, setImageTab] = React.useState<'upload' | 'url'>(() =>
    initial?.imageUrl?.startsWith('http') ? 'url' : 'upload'
  );
  const [fileName, setFileName] = React.useState<string>('');
  const [fileSize, setFileSize] = React.useState<string>('');
  const [dragActive, setDragActive] = React.useState(false);
  const [imageError, setImageError] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (open) {
      if (initial) {
        setForm(getInitialProjectForm(initial, isFeaturedOnHome));
        if (initial.imageUrl?.startsWith('http')) {
          setImageTab('url');
        } else {
          setImageTab('upload');
        }
      } else {
        setForm({ ...EMPTY_PROJECT_FORM, showOnHomepage: isFeaturedOnHome });
        setImageTab('upload');
      }
      setFileName('');
      setFileSize('');
      setImageError(false);
    }
  }, [open, initial, isFeaturedOnHome]);

  const patch = (key: keyof ProjectFormState, value: string) => {
    setForm((f) => {
      const updated = { ...f, [key]: value };
      // Auto-generate slug and projectUrl if title is updated in create mode
      if (key === 'title' && mode === 'create' && !f.slug) {
        const slugified = value
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '');
        updated.slug = slugified;
        if (!f.projectUrl && slugified) {
          updated.projectUrl = `https://${slugified}.com`;
        }
      }
      return updated;
    });
    if (key === 'imageUrl') setImageError(false);
  };

  const handleFileSelect = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      notify.error('Please select an image file (PNG, JPG, WebP, SVG).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      notify.error('File size exceeds 5MB. Please choose a smaller image.');
      return;
    }

    setFileName(file.name);
    setFileSize((file.size / 1024).toFixed(1) + ' KB');

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        patch('imageUrl', result);
        notify.success(`Image uploaded: ${file.name}`);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const clearImage = () => {
    patch('imageUrl', '');
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      notify.error('Project title is required.');
      return;
    }
    if (!form.imageUrl.trim()) {
      notify.error('Cover image is required. Please upload an image or provide a URL.');
      return;
    }

    const tags = form.tagsString
      ? form.tagsString
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean)
      : [];

    onSubmit(
      {
        orderNumber: form.orderNumber || undefined,
        title: form.title.trim(),
        slug: form.slug.trim() || undefined,
        client: form.client.trim() || undefined,
        categoryId: form.categoryId || null,
        projectDate: form.projectDate || undefined,
        metrics: form.metrics.trim() || undefined,
        projectUrl: form.projectUrl.trim() || undefined,
        imageUrl: form.imageUrl.trim(),
        description: form.description.trim() || undefined,
        tags,
        status: form.status,
      },
      form.showOnHomepage
    );
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="w-[95vw] max-w-4xl max-h-[92vh] rounded-2xl border-slate-200 bg-white shadow-2xl p-0 flex flex-col overflow-hidden">
        {/* Header */}
        <DialogHeader className="px-6 pt-5 pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Briefcase className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle className="text-base font-bold text-slate-900">
                {mode === 'create' ? 'Add Portfolio Showcase Project' : 'Edit Showcase Project'}
              </DialogTitle>
              <DialogDescription className="text-xs text-slate-500 mt-0.5">
                {mode === 'create'
                  ? 'Configure the production case study for the interactive portfolio showcase.'
                  : 'Update project classification, media asset, metrics, and details.'}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Section 1: Title & Order */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="sm:col-span-1 space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Order # <span className="text-slate-400 font-normal">(e.g. 01)</span>
              </label>
              <Input
                value={form.orderNumber}
                onChange={(e) => patch('orderNumber', e.target.value)}
                placeholder="01"
                className="font-mono text-sm"
              />
            </div>

            <div className="sm:col-span-3 space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Project Title <span className="text-rose-500">*</span>
              </label>
              <Input
                value={form.title}
                onChange={(e) => patch('title', e.target.value)}
                placeholder="Apex Capital Derivatives Exchange"
                required
                className="text-sm font-medium"
              />
            </div>
          </div>

          {/* Section 2: Slug & Client */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Project Slug <span className="text-slate-400 font-normal">(URL Key)</span>
              </label>
              <Input
                value={form.slug}
                onChange={(e) => patch('slug', e.target.value)}
                placeholder="apex-capital-derivatives"
                className="font-mono text-xs"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Client Organization
              </label>
              <Input
                value={form.client}
                onChange={(e) => patch('client', e.target.value)}
                placeholder="Apex Capital Management"
                className="text-sm"
              />
            </div>
          </div>

          {/* Section 3: Category & Project Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">Category</label>
              <select
                value={form.categoryId}
                onChange={(e) => patch('categoryId', e.target.value)}
                className="w-full h-9 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                <option value="">Uncategorized</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-primary" />
                <span>Date of Project</span>
                <span className="text-slate-400 font-normal text-[11px]">(DD/MM/YYYY)</span>
              </label>
              <Input
                type="date"
                value={form.projectDate}
                onChange={(e) => patch('projectDate', e.target.value)}
                className="text-xs font-mono"
              />
              {form.projectDate && (
                <div className="text-[11px] font-mono text-muted-foreground flex items-center gap-1.5">
                  <span className="text-slate-500 font-medium">Date (DD/MM/YYYY):</span>
                  <span className="font-semibold text-primary">{formatDateDDMMYYYY(form.projectDate)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Publication Status: Draft vs Public */}
          <StatusToggleField
            value={form.status}
            onChange={(status) => patch('status', status)}
          />

          {/* Home Page Showcase Visibility Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl border border-border/80 bg-slate-50/70 dark:bg-slate-900/40">
            <div className="space-y-0.5 pr-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                  Show on Home Page
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    form.showOnHomepage
                      ? 'bg-[#d9127b]/10 text-[#d9127b]'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {form.showOnHomepage ? 'Featured on Home' : 'Hidden from Home'}
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground leading-tight">
                Control whether this project appears in the curated portfolio showcase grid on the Home page.
              </p>
            </div>
            <Switch
              checked={form.showOnHomepage}
              onCheckedChange={(checked) => setForm((f) => ({ ...f, showOnHomepage: checked }))}
            />
          </div>

          {/* Section 4: Direct Image Upload / URL Tabbed Media Asset */}
          <div className="space-y-2 pt-1 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <span>Cover Image</span>
                <span className="text-rose-500">*</span>
                <span className="text-slate-400 font-normal text-[11px]">(PNG, JPG, WebP, SVG)</span>
              </label>

              {/* Tab Switcher: Direct Upload vs URL */}
              <div className="inline-flex rounded-lg p-0.5 bg-slate-100 border border-slate-200/80">
                <button
                  type="button"
                  onClick={() => setImageTab('upload')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1.5 ${
                    imageTab === 'upload'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Upload className="h-3 w-3" />
                  Direct Upload
                </button>
                <button
                  type="button"
                  onClick={() => setImageTab('url')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1.5 ${
                    imageTab === 'url'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Link2 className="h-3 w-3" />
                  Image URL
                </button>
              </div>
            </div>

            {/* Hidden native file input */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFileSelect(e.target.files[0]);
              }}
            />

            {/* Direct Upload Tab */}
            {imageTab === 'upload' ? (
              form.imageUrl ? (
                /* Uploaded preview card */
                <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 bg-slate-50/70">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-14 w-20 rounded-lg bg-neutral-900 border border-slate-200 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={form.imageUrl}
                        alt="Project Cover Preview"
                        className="h-full w-full object-cover"
                        onError={() => setImageError(true)}
                      />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-800 truncate">
                        {fileName || 'Project Cover Image'}
                      </p>
                      <p className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 inline-block" />
                        Image ready {fileSize ? `(${fileSize})` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      className="text-xs h-8"
                    >
                      Change
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={clearImage}
                      className="text-xs h-8 text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ) : (
                /* Drag and drop target */
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
                    dragActive
                      ? 'border-primary bg-primary/5'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="h-9 w-9 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-2">
                    <Upload className="h-4 w-4" />
                  </div>
                  <p className="text-xs font-semibold text-slate-700">
                    Click to upload or drag & drop cover image
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    PNG, JPG, WebP up to 5MB (1200×800 recommended)
                  </p>
                </div>
              )
            ) : (
              /* URL Mode */
              <div className="space-y-2">
                <Input
                  value={form.imageUrl}
                  onChange={(e) => patch('imageUrl', e.target.value)}
                  placeholder="https://images.unsplash.com/photo-..."
                  className="text-xs font-mono"
                />
                {form.imageUrl && (
                  <div className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 bg-slate-50/70">
                    <div className="h-12 w-16 rounded bg-neutral-900 overflow-hidden shrink-0 flex items-center justify-center">
                      {!imageError ? (
                        /* eslint-disable-next-line @next/next/no-img-element */
                        <img
                          src={form.imageUrl}
                          alt="URL Preview"
                          className="h-full w-full object-cover"
                          onError={() => setImageError(true)}
                        />
                      ) : (
                        <ImageOff className="h-4 w-4 text-slate-400" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-slate-700 truncate">
                        {imageError ? 'Invalid image URL or failed to load' : 'Image loaded successfully'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 5: Key Metrics & Project URL */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Key Metric / Impact Result
              </label>
              <Input
                value={form.metrics}
                onChange={(e) => patch('metrics', e.target.value)}
                placeholder="$40B+ Daily Volume · 99.999% SLA"
                className="text-xs font-mono text-emerald-700"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Client Store / Website URL <span className="text-slate-400 font-normal">(Redirect Link)</span>
              </label>
              <Input
                value={form.projectUrl}
                onChange={(e) => patch('projectUrl', e.target.value)}
                placeholder="https://clientstore.com"
                className="text-xs font-mono"
              />
            </div>
          </div>

          {/* Section 6: Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700">
              Technology Tags <span className="text-slate-400 font-normal">(comma-separated)</span>
            </label>
            <Input
              value={form.tagsString}
              onChange={(e) => patch('tagsString', e.target.value)}
              placeholder="Next.js, TypeScript, pgvector, Kubernetes"
              className="text-xs"
            />
          </div>

          {/* Section 7: Description / Summary with RichTextEditor */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700">Project Summary</label>
              <span className="text-[11px] text-muted-foreground hidden sm:inline">
                Rich text markdown, media links, lists, code, and live preview
              </span>
            </div>
            <RichTextEditor
              value={form.description}
              onChange={(content) => patch('description', content)}
              placeholder="Write detailed project summary, technical architecture, and impact highlights in rich markdown..."
              minHeight="260px"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="text-xs"
            >
              {saving ? (
                <>
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                  Saving...
                </>
              ) : mode === 'create' ? (
                'Create Project'
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Category Popup Modal ────────────────────────────────────────────────────

interface CategoryDialogProps {
  open: boolean;
  mode: 'create' | 'edit';
  initial?: PortfolioCategoryRecord | null;
  saving: boolean;
  onClose: () => void;
  onSubmit: (form: Record<string, any>) => void;
}

function getInitialCategoryForm(initial?: PortfolioCategoryRecord | null): CategoryFormState {
  if (!initial) return EMPTY_CATEGORY_FORM;
  return {
    name: initial.name || '',
    slug: initial.slug || '',
    displayOrder: String(initial.displayOrder ?? 1),
    description: initial.description || '',
    status: (initial.status as string) || 'PUBLISHED',
  };
}

function CategoryDialog({
  open,
  mode,
  initial,
  saving,
  onClose,
  onSubmit,
}: CategoryDialogProps) {
  const [form, setForm] = React.useState<CategoryFormState>(() => getInitialCategoryForm(initial));

  React.useEffect(() => {
    if (open) {
      if (initial) {
        setForm(getInitialCategoryForm(initial));
      } else {
        setForm(EMPTY_CATEGORY_FORM);
      }
    }
  }, [open, initial]);

  const patch = (key: keyof CategoryFormState, value: string) => {
    setForm((f) => {
      const updated = { ...f, [key]: value };
      if (key === 'name' && mode === 'create' && !f.slug) {
        updated.slug = value
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '');
      }
      return updated;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      notify.error('Category name is required.');
      return;
    }

    onSubmit({
      name: form.name.trim(),
      slug: form.slug.trim() || undefined,
      displayOrder: form.displayOrder ? Number(form.displayOrder) : undefined,
      description: form.description.trim() || undefined,
      status: form.status,
    });
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="w-[95vw] max-w-lg rounded-2xl border-slate-200 bg-white shadow-2xl p-0 overflow-hidden">
        {/* Header */}
        <DialogHeader className="px-6 pt-5 pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <FolderTree className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle className="text-base font-bold text-slate-900">
                {mode === 'create' ? 'Add Portfolio Category' : 'Edit Category'}
              </DialogTitle>
              <DialogDescription className="text-xs text-slate-500 mt-0.5">
                {mode === 'create'
                  ? 'Define a domain category for filtering showcase works on /portfolio.'
                  : 'Update category name, URL slug, ordering, or description.'}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2 space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">
                Category Name <span className="text-rose-500">*</span>
              </label>
              <Input
                value={form.name}
                onChange={(e) => patch('name', e.target.value)}
                placeholder="Financial Infrastructure"
                required
                className="text-sm font-medium"
              />
            </div>

            <div className="sm:col-span-1 space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">Display Order</label>
              <Input
                type="number"
                value={form.displayOrder}
                onChange={(e) => patch('displayOrder', e.target.value)}
                placeholder="1"
                className="font-mono text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700">URL Slug</label>
              <Input
                value={form.slug}
                onChange={(e) => patch('slug', e.target.value)}
                placeholder="financial-infrastructure"
                className="font-mono text-xs"
              />
            </div>
          </div>

          {/* Publication Status: Draft vs Public */}
          <StatusToggleField
            value={form.status}
            onChange={(status) => patch('status', status)}
          />

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700">Description</label>
            <Textarea
              value={form.description}
              onChange={(e) => patch('description', e.target.value)}
              placeholder="Ultra-low-latency distributed clearing architectures, ledger networks..."
              rows={3}
              className="text-xs leading-relaxed"
            />
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={saving}
              className="text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saving}
              className="text-xs"
            >
              {saving ? (
                <>
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                  Saving...
                </>
              ) : mode === 'create' ? (
                'Create Category'
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Admin Page Component ───────────────────────────────────────────────

export default function PortfolioAdminPage() {
  const [activeTab, setActiveTab] = React.useState<'projects' | 'categories' | 'settings'>('projects');

  // Synchronize activeTab with URL search parameters (?tab=categories | ?tab=projects | ?tab=settings)
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      if (tabParam === 'categories' || tabParam === 'settings' || tabParam === 'projects') {
        setActiveTab(tabParam);
      }
    }
  }, []);

  const handleTabChange = (tab: 'projects' | 'categories' | 'settings') => {
    setActiveTab(tab);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('tab', tab);
      window.history.replaceState({}, '', url.toString());
    }
  };

  // Data states
  const [projects, setProjects] = React.useState<PortfolioProjectRecord[]>([]);
  const [categories, setCategories] = React.useState<PortfolioCategoryRecord[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [portfolioSection, setPortfolioSection] = React.useState<{ id: string; contentPayload: Record<string, any> } | null>(null);
  const [homePortfolioSection, setHomePortfolioSection] = React.useState<{ id: string; contentPayload: Record<string, any> } | null>(null);
  const [settingsSaving, setSettingsSaving] = React.useState(false);

  // Dialog states
  const [projectDialogOpen, setProjectDialogOpen] = React.useState(false);
  const [editingProject, setEditingProject] = React.useState<PortfolioProjectRecord | null>(null);
  const [projectSaving, setProjectSaving] = React.useState(false);

  const [categoryDialogOpen, setCategoryDialogOpen] = React.useState(false);
  const [editingCategory, setEditingCategory] = React.useState<PortfolioCategoryRecord | null>(null);
  const [categorySaving, setCategorySaving] = React.useState(false);

  // Fetch data
  const loadData = React.useCallback(async () => {
    setLoading(true);
    try {
      const [projData, catData, pageRes, homeRes] = await Promise.all([
        fetchApi<any>('/portfolio/admin/projects').catch(() =>
          fetchApi<any>('/portfolio').then((r: any) => r?.projects || r?.data?.projects || r || [])
        ),
        fetchApi<any>('/portfolio/admin/categories').catch(() =>
          fetchApi<any>('/portfolio/categories').then((r: any) => r?.data || r || [])
        ),
        fetchApi<any>('/pages/portfolio').catch(() => null),
        fetchApi<any>('/pages/home').catch(() => null),
      ]);

      const resolvedProjects = Array.isArray(projData)
        ? projData
        : (Array.isArray(projData?.projects)
          ? projData.projects
          : (Array.isArray(projData?.data?.projects)
            ? projData.data.projects
            : (Array.isArray(projData?.data) ? projData.data : [])));

      const resolvedCategories = Array.isArray(catData)
        ? catData
        : (Array.isArray(catData?.data) ? catData.data : []);

      setProjects(resolvedProjects);
      setCategories(resolvedCategories);

      const pageData = pageRes?.data || pageRes;
      if (pageData?.sections) {
        const sec = pageData.sections.find(
          (s: any) =>
            s.sectionIdentifier === 'our-work-portfolio' ||
            s.sectionIdentifier === 'portfolio-showcase' ||
            s.sectionIdentifier === 'portfolio' ||
            s.componentType === 'PORTFOLIO',
        );
        if (sec) {
          setPortfolioSection({ id: sec.id, contentPayload: sec.contentPayload || {} });
        }
      }

      const homeData = homeRes?.data || homeRes;
      if (homeData?.sections) {
        const hSec = homeData.sections.find(
          (s: any) =>
            s.sectionIdentifier === 'portfolio-showcase' ||
            s.sectionIdentifier === 'our-work' ||
            s.sectionIdentifier === 'our-work-portfolio' ||
            s.sectionIdentifier === 'portfolio' ||
            s.componentType === 'PORTFOLIO',
        );
        if (hSec) {
          setHomePortfolioSection({ id: hSec.id, contentPayload: hSec.contentPayload || {} });
        }
      }
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to load portfolio data.'));
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadData();
  }, [loadData]);

  // Update setting toggle
  const handleUpdateSettingToggle = async (key: string, value: boolean) => {
    if (!portfolioSection) return;
    const nextPayload = {
      ...portfolioSection.contentPayload,
      [key]: value,
    };
    setPortfolioSection({ ...portfolioSection, contentPayload: nextPayload });
    setSettingsSaving(true);
    try {
      await fetchApi(`/sections/${portfolioSection.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          contentPayload: nextPayload,
        }),
      });
      notify.success('Portfolio page settings saved.');
    } catch {
      notify.error('Failed to save portfolio page settings.');
    } finally {
      setSettingsSaving(false);
    }
  };

  // Update Home page portfolio setting toggle
  const handleUpdateHomeSetting = async (key: string, value: any) => {
    if (!homePortfolioSection) return;
    const nextPayload = {
      ...homePortfolioSection.contentPayload,
      [key]: value,
    };
    setHomePortfolioSection({ ...homePortfolioSection, contentPayload: nextPayload });
    setSettingsSaving(true);
    try {
      await fetchApi(`/sections/${homePortfolioSection.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          contentPayload: nextPayload,
        }),
      });
      notify.success('Home page portfolio settings saved.');
    } catch {
      notify.error('Failed to save Home page portfolio settings.');
    } finally {
      setSettingsSaving(false);
    }
  };

  // Toggle a project on the Home Page showcase
  const handleToggleShowOnHome = async (projectId: string, currentStatus: boolean) => {
    if (!homePortfolioSection) {
      notify.error('Home page portfolio section not found.');
      return;
    }
    const currentSelected: string[] = Array.isArray(homePortfolioSection.contentPayload.selectedProjectIds)
      ? homePortfolioSection.contentPayload.selectedProjectIds
      : [];

    const nextSelected = currentStatus
      ? currentSelected.filter((id) => id !== projectId)
      : [...currentSelected, projectId];

    const nextPayload = {
      ...homePortfolioSection.contentPayload,
      selectedProjectIds: nextSelected,
    };
    setHomePortfolioSection({ ...homePortfolioSection, contentPayload: nextPayload });
    try {
      await fetchApi(`/sections/${homePortfolioSection.id}`, {
        method: 'PUT',
        body: JSON.stringify({ contentPayload: nextPayload }),
      });
      notify.success(
        currentStatus
          ? 'Project removed from Home page showcase.'
          : 'Project added to Home page showcase.'
      );
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Failed to update Home page showcase.'));
    }
  };

  // ─── Project Operations ──────────────────────────────────────────────────────

  const handleCreateProject = async (form: Record<string, any>, showOnHomepage?: boolean) => {
    setProjectSaving(true);
    try {
      const res: any = await fetchApi('/portfolio', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      const newId = res?.id || res?.data?.id;
      if (newId && showOnHomepage !== undefined && homePortfolioSection) {
        await handleToggleShowOnHome(newId, !showOnHomepage);
      }
      notify.success('Portfolio project created successfully.');
      setProjectDialogOpen(false);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to create portfolio project.'));
    } finally {
      setProjectSaving(false);
    }
  };

  const handleUpdateProject = async (id: string, form: Record<string, any>, showOnHomepage?: boolean) => {
    setProjectSaving(true);
    try {
      await fetchApi(`/portfolio/${id}`, {
        method: 'PUT',
        body: JSON.stringify(form),
      });
      if (showOnHomepage !== undefined && homePortfolioSection) {
        const currentlySelected = Array.isArray(homePortfolioSection.contentPayload?.selectedProjectIds)
          ? homePortfolioSection.contentPayload.selectedProjectIds.includes(id)
          : false;
        if (currentlySelected !== showOnHomepage) {
          await handleToggleShowOnHome(id, currentlySelected);
        }
      }
      notify.success('Portfolio project updated successfully.');
      setProjectDialogOpen(false);
      setTimeout(() => setEditingProject(null), 300);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to update portfolio project.'));
    } finally {
      setProjectSaving(false);
    }
  };

  const handleDeleteProject = async (id: string) => {
    await fetchApi(`/portfolio/${id}`, {
      method: 'DELETE',
    });
    loadData();
  };

  const handleBulkDeleteProjects = async (ids: string[]) => {
    await fetchApi('/portfolio/bulk-delete', {
      method: 'POST',
      body: JSON.stringify({ ids }),
    });
    loadData();
  };

  const handleBulkStatusChangeProjects = async (ids: string[], status: ItemStatus) => {
    try {
      await Promise.all(
        ids.map((id) =>
          fetchApi(`/portfolio/${id}`, {
            method: 'PUT',
            body: JSON.stringify({ status }),
          })
        )
      );
      notify.success(`${ids.length} projects status updated.`);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to update status for selected projects.'));
    }
  };

  // ─── Category Operations ─────────────────────────────────────────────────────

  const handleCreateCategory = async (form: Record<string, any>) => {
    setCategorySaving(true);
    try {
      await fetchApi('/portfolio/categories', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      notify.success('Category created successfully.');
      setCategoryDialogOpen(false);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to create category.'));
    } finally {
      setCategorySaving(false);
    }
  };

  const handleUpdateCategory = async (id: string, form: Record<string, any>) => {
    setCategorySaving(true);
    try {
      await fetchApi(`/portfolio/categories/${id}`, {
        method: 'PUT',
        body: JSON.stringify(form),
      });
      notify.success('Category updated successfully.');
      setCategoryDialogOpen(false);
      setTimeout(() => setEditingCategory(null), 300);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to update category.'));
    } finally {
      setCategorySaving(false);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    await fetchApi(`/portfolio/categories/${id}`, {
      method: 'DELETE',
    });
    loadData();
  };

  const handleBulkDeleteCategories = async (ids: string[]) => {
    await fetchApi('/portfolio/categories/bulk-delete', {
      method: 'POST',
      body: JSON.stringify({ ids }),
    });
    loadData();
  };

  const handleBulkStatusChangeCategories = async (ids: string[], status: ItemStatus) => {
    try {
      await Promise.all(
        ids.map((id) =>
          fetchApi(`/portfolio/categories/${id}`, {
            method: 'PUT',
            body: JSON.stringify({ status }),
          })
        )
      );
      notify.success(`${ids.length} categories status updated.`);
      loadData();
    } catch (err) {
      notify.error(normalizeErrorMessage(err, 'Unable to update status for selected categories.'));
    }
  };

  // ─── Table Columns ───────────────────────────────────────────────────────────

  const projectColumns: ColumnDef<PortfolioProjectRecord>[] = [
    {
      key: 'orderNumber',
      header: '# Order',
      sortable: true,
      className: 'w-20 whitespace-nowrap',
      render: (item) => (
        <span className="font-mono text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md inline-block">
          {item.orderNumber || '--'}
        </span>
      ),
    },
    {
      key: 'title',
      header: 'Project Title',
      sortable: true,
      className: 'min-w-[280px] max-w-[360px]',
      render: (item) => (
        <div className="flex items-center gap-3">
          {item.imageUrl && (
            <div className="h-10 w-14 rounded-md bg-neutral-900 overflow-hidden shrink-0 border border-slate-200 dark:border-slate-800 shadow-2xs">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.imageUrl}
                alt={item.title}
                className="h-full w-full object-cover"
              />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <span className="font-semibold text-slate-900 dark:text-slate-100 text-xs sm:text-sm line-clamp-1 leading-snug">
              {item.title}
            </span>
            {item.projectUrl && (
              <a
                href={item.projectUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-[11px] text-blue-600 hover:text-blue-700 hover:underline flex items-center gap-1 w-fit mt-0.5"
                onClick={(e) => e.stopPropagation()}
              >
                <span className="truncate max-w-[220px]">{item.projectUrl}</span>
                <ExternalLink className="w-2.5 h-2.5 shrink-0" />
              </a>
            )}
          </div>
        </div>
      ),
    },
    {
      key: 'client',
      header: 'Client',
      sortable: true,
      className: 'min-w-[120px] whitespace-nowrap',
      render: (item) => <span className="font-medium text-slate-800 dark:text-slate-200 text-xs">{item.client || '—'}</span>,
    },
    {
      key: 'category',
      header: 'Category',
      className: 'min-w-[180px] whitespace-nowrap',
      render: (item) => (
        <Badge
          variant="outline"
          className="text-[11px] font-medium whitespace-nowrap inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-800"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-primary/70 shrink-0" />
          <span>{item.category || 'Uncategorized'}</span>
        </Badge>
      ),
    },
    {
      key: 'projectDate',
      header: 'Project Date',
      sortable: true,
      className: 'min-w-[130px] whitespace-nowrap',
      render: (item) => {
        const d = item.projectDate || item.createdAt;
        return (
          <span className="font-mono text-xs text-muted-foreground whitespace-nowrap flex items-center gap-1.5">
            <Calendar className="w-3 h-3 text-primary/70 shrink-0" />
            <span>{d ? formatDateDDMMYYYY(d) : '—'}</span>
          </span>
        );
      },
    },
    {
      key: 'metrics',
      header: 'Impact Metric',
      className: 'min-w-[180px] max-w-[240px]',
      render: (item) => (
        <span className="font-mono text-xs text-emerald-600 dark:text-emerald-400 font-semibold leading-relaxed inline-block">
          {item.metrics || '—'}
        </span>
      ),
    },
    {
      key: 'homeShowcase',
      header: 'Home Page',
      className: 'min-w-[130px] whitespace-nowrap text-center',
      render: (item) => {
        const selectedOnHome = Array.isArray(homePortfolioSection?.contentPayload?.selectedProjectIds)
          ? homePortfolioSection.contentPayload.selectedProjectIds.includes(item.id)
          : false;
        return (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleToggleShowOnHome(item.id, selectedOnHome);
            }}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold transition-all cursor-pointer ${
              selectedOnHome
                ? 'bg-[#d9127b]/15 text-[#d9127b] border border-[#d9127b]/30 shadow-2xs hover:bg-[#d9127b]/25'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200/60 dark:border-slate-700'
            }`}
            title={selectedOnHome ? 'Click to remove from Home page' : 'Click to feature on Home page'}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                selectedOnHome ? 'bg-[#d9127b]' : 'bg-slate-400'
              }`}
            />
            <span>{selectedOnHome ? 'Featured' : 'Hidden'}</span>
          </button>
        );
      },
    },
    {
      key: 'updatedAt',
      header: 'Updated',
      sortable: true,
      className: 'min-w-[110px] whitespace-nowrap',
      render: (item) => (
        <span className="font-mono text-[11px] text-muted-foreground whitespace-nowrap">
          {formatDate(item.updatedAt)}
        </span>
      ),
    },
  ];

  const categoryColumns: ColumnDef<PortfolioCategoryRecord>[] = [
    {
      key: 'displayOrder',
      header: '# Order',
      sortable: true,
      className: 'w-20 whitespace-nowrap',
      render: (item) => (
        <span className="font-mono text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md inline-block">
          {String(item.displayOrder ?? 0).padStart(2, '0')}
        </span>
      ),
    },
    {
      key: 'name',
      header: 'Category Name',
      sortable: true,
      className: 'min-w-[200px]',
      render: (item) => (
        <div>
          <span className="font-semibold text-slate-900 dark:text-slate-100">{item.name}</span>
          <div className="font-mono text-[11px] text-slate-400">/{item.slug}</div>
        </div>
      ),
    },
    {
      key: 'description',
      header: 'Description',
      className: 'min-w-[240px]',
      render: (item) => (
        <span className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1 max-w-sm">
          {item.description || '—'}
        </span>
      ),
    },
    {
      key: 'projectCount',
      header: 'Projects',
      sortable: true,
      className: 'min-w-[130px] whitespace-nowrap',
      render: (item) => (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-muted text-muted-foreground whitespace-nowrap">
          <span className="font-bold text-foreground">{item.projectCount ?? 0}</span>
          <span>{item.projectCount === 1 ? 'project' : 'projects'}</span>
        </span>
      ),
    },
    {
      key: 'updatedAt',
      header: 'Updated',
      sortable: true,
      className: 'min-w-[110px] whitespace-nowrap',
      render: (item) => (
        <span className="font-mono text-[11px] text-muted-foreground whitespace-nowrap">
          {formatDate(item.updatedAt)}
        </span>
      ),
    },
  ];

  const portfolioTabs = (
    <div className="flex items-center gap-1.5 p-1 bg-muted/60 rounded-xl w-fit">
      <button
        type="button"
        onClick={() => handleTabChange('projects')}
        className={cn(
          'inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer',
          activeTab === 'projects'
            ? 'bg-card text-foreground shadow-xs'
            : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
        )}
      >
        <Briefcase className="w-3.5 h-3.5" />
        <span>Projects</span>
        <span
          className={cn(
            'text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold',
            activeTab === 'projects' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
          )}
        >
          {projects.length}
        </span>
      </button>

      <button
        type="button"
        onClick={() => handleTabChange('categories')}
        className={cn(
          'inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer',
          activeTab === 'categories'
            ? 'bg-card text-foreground shadow-xs'
            : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
        )}
      >
        <FolderTree className="w-3.5 h-3.5" />
        <span>Categories</span>
        <span
          className={cn(
            'text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold',
            activeTab === 'categories' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'
          )}
        >
          {categories.length}
        </span>
      </button>

      <button
        type="button"
        onClick={() => handleTabChange('settings')}
        className={cn(
          'inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer',
          activeTab === 'settings'
            ? 'bg-card text-foreground shadow-xs'
            : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
        )}
      >
        <SlidersHorizontal className="w-3.5 h-3.5" />
        <span>Page Settings</span>
      </button>
    </div>
  );

  return (
    <>
      {/* ── Tab 1: Projects Table ──────────────────────────────────────────────── */}
      {activeTab === 'projects' && (
        <>
          <DataTable<PortfolioProjectRecord>
            title="Portfolio & Case Studies"
            description="Manage the enterprise production case studies and showcase projects displayed on the /portfolio page."
            data={projects}
            loading={loading}
            columns={projectColumns}
            searchKeys={['title', 'client', 'category', 'metrics']}
            requiredPermission="content:write"
            addButtonLabel="New Showcase Project"
            tabs={portfolioTabs}
            onAdd={() => {
              setEditingProject(null);
              setProjectDialogOpen(true);
            }}
            onEdit={(item) => {
              setEditingProject(item);
              setProjectDialogOpen(true);
            }}
            onDelete={(id) => handleDeleteProject(id)}
            onBulkDelete={handleBulkDeleteProjects}
            onBulkStatusChange={handleBulkStatusChangeProjects}
          />

          <ProjectDialog
            key={editingProject?.id || 'portfolio-project-dialog'}
            open={projectDialogOpen}
            mode={editingProject ? 'edit' : 'create'}
            initial={editingProject}
            categories={categories}
            isFeaturedOnHome={
              editingProject
                ? (Array.isArray(homePortfolioSection?.contentPayload?.selectedProjectIds)
                  ? homePortfolioSection.contentPayload.selectedProjectIds.includes(editingProject.id)
                  : true)
                : true
            }
            saving={projectSaving}
            onClose={() => {
              setProjectDialogOpen(false);
              setTimeout(() => setEditingProject(null), 300);
            }}
            onSubmit={(form, showOnHomepage) => {
              if (editingProject) {
                handleUpdateProject(editingProject.id, form, showOnHomepage);
              } else {
                handleCreateProject(form, showOnHomepage);
              }
            }}
          />
        </>
      )}

      {/* ── Tab 2: Categories Table ────────────────────────────────────────────── */}
      {activeTab === 'categories' && (
        <>
          <DataTable<PortfolioCategoryRecord>
            title="Portfolio & Case Studies"
            description="Manage domain categories for organizing portfolio projects. Categories appear in display order in the filter on /portfolio."
            data={categories}
            loading={loading}
            columns={categoryColumns}
            searchKeys={['name', 'slug', 'description']}
            requiredPermission="content:write"
            addButtonLabel="New Category"
            tabs={portfolioTabs}
            onAdd={() => {
              setEditingCategory(null);
              setCategoryDialogOpen(true);
            }}
            onEdit={(item) => {
              setEditingCategory(item);
              setCategoryDialogOpen(true);
            }}
            onDelete={(id) => handleDeleteCategory(id)}
            onBulkDelete={handleBulkDeleteCategories}
            onBulkStatusChange={handleBulkStatusChangeCategories}
          />

          <CategoryDialog
            key={editingCategory?.id || 'portfolio-category-dialog'}
            open={categoryDialogOpen}
            mode={editingCategory ? 'edit' : 'create'}
            initial={editingCategory}
            saving={categorySaving}
            onClose={() => {
              setCategoryDialogOpen(false);
              setTimeout(() => setEditingCategory(null), 300);
            }}
            onSubmit={(form) => {
              if (editingCategory) {
                handleUpdateCategory(editingCategory.id, form);
              } else {
                handleCreateCategory(form);
              }
            }}
          />
        </>
      )}

      {/* ── Tab 3: Page Settings (Homepage Integrations) ────────────────────────── */}
      {activeTab === 'settings' && (
        <AdminContentContainer variant="wide">
          <AdminPageHeader
            title="Portfolio & Case Studies"
            description="Enable or disable shared global sections brought directly from the Home page."
            tabs={portfolioTabs}
          />
          <Card className="border-border">
            <CardHeader className="border-b border-border/40 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <SlidersHorizontal className="w-5 h-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-semibold">Portfolio Page Settings & Integrations</CardTitle>
                    <CardDescription className="text-xs text-muted-foreground mt-0.5">
                      Enable or disable shared global sections brought directly from the Home page.
                    </CardDescription>
                  </div>
                </div>
                {settingsSaving && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-primary" />
                    Saving...
                  </div>
                )}
              </div>
            </CardHeader>

            <CardContent className="p-6 space-y-6">
              <div className="rounded-xl border border-border/60 bg-muted/20 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                      <label htmlFor="toggle-contact" className="font-semibold text-sm cursor-pointer">
                        DIRECT ENGAGEMENT Section (Contact / Inquiry)
                      </label>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                        Home Page Component
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Renders the interactive consultation form, contact details, and direct engagement channels immediately below the portfolio showcase grid. All content, copy, and form settings are inherited directly from the Home Page.
                    </p>
                  </div>
                  <Switch
                    id="toggle-contact"
                    checked={portfolioSection?.contentPayload?.showContactSection !== false}
                    onCheckedChange={(checked) => handleUpdateSettingToggle('showContactSection', checked)}
                    disabled={!portfolioSection || settingsSaving}
                  />
                </div>
              </div>

              <div className="rounded-xl border border-border/60 bg-muted/20 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Megaphone className="w-4 h-4 text-primary shrink-0" />
                      <label htmlFor="toggle-cta" className="font-semibold text-sm cursor-pointer">
                        CTA Banner Section
                      </label>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-primary/10 text-primary font-bold">
                        Home Page Component
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Renders the high-impact conversion call-to-action banner right before the footer. Copy, buttons, and design styling are synchronized automatically from the Home Page CTA section.
                    </p>
                  </div>
                  <Switch
                    id="toggle-cta"
                    checked={portfolioSection?.contentPayload?.showCtaSection !== false}
                    onCheckedChange={(checked) => handleUpdateSettingToggle('showCtaSection', checked)}
                    disabled={!portfolioSection || settingsSaving}
                  />
                </div>
              </div>

              {/* ── Home Page Showcase Settings ── */}
              <div className="rounded-xl border border-border/60 bg-muted/20 p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-[#d9127b] shrink-0" />
                      <span className="font-semibold text-sm">
                        Home Page Showcase Settings
                      </span>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#d9127b]/10 text-[#d9127b] font-bold">
                        Home Page Section
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Configure how portfolio projects appear in the Home page showcase grid.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-background">
                    <div>
                      <span className="text-xs font-semibold block">Show Category Tabs on Home Page</span>
                      <p className="text-[11px] text-muted-foreground">
                        Keep off to hide category tabs on Home page
                      </p>
                    </div>
                    <Switch
                      checked={Boolean(homePortfolioSection?.contentPayload?.showCategoryFilter)}
                      onCheckedChange={(checked) => handleUpdateHomeSetting('showCategoryFilter', checked)}
                      disabled={!homePortfolioSection || settingsSaving}
                    />
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-background">
                    <div>
                      <span className="text-xs font-semibold block">Show &quot;View All Portfolio&quot; Button</span>
                      <p className="text-[11px] text-muted-foreground">
                        Links visitors directly to full /portfolio
                      </p>
                    </div>
                    <Switch
                      checked={homePortfolioSection?.contentPayload?.showViewAllButton !== false}
                      onCheckedChange={(checked) => handleUpdateHomeSetting('showViewAllButton', checked)}
                      disabled={!homePortfolioSection || settingsSaving}
                    />
                  </div>
                </div>

                {homePortfolioSection?.contentPayload?.showViewAllButton !== false && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-muted-foreground">Button Label</label>
                      <Input
                        value={homePortfolioSection?.contentPayload?.viewAllButtonLabel || 'View All Portfolio'}
                        onChange={(e) => handleUpdateHomeSetting('viewAllButtonLabel', e.target.value)}
                        placeholder="View All Portfolio"
                        className="h-8 text-xs"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] font-medium text-muted-foreground">Button URL</label>
                      <Input
                        value={homePortfolioSection?.contentPayload?.viewAllButtonUrl || '/portfolio'}
                        onChange={(e) => handleUpdateHomeSetting('viewAllButtonUrl', e.target.value)}
                        placeholder="/portfolio"
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border/40 text-xs text-muted-foreground">
                <span>To customize the copy, input fields, or button texts, edit the sections in the Pages Studio:</span>
                <a
                  href="/pages"
                  className="inline-flex items-center gap-1.5 text-primary hover:underline font-medium transition-colors"
                >
                  Go to Pages Studio <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </CardContent>
          </Card>
        </AdminContentContainer>
      )}
    </>
  );
}
