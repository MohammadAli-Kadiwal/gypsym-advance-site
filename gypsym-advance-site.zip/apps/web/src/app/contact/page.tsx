import * as React from 'react';
import type { Metadata } from 'next';
import { ArrowUpRight, Mail } from 'lucide-react';
import { getPageBySlug, getContactSettings } from '@/lib/api';
import { ContactSection } from '@/components/cms/contact-section';
import { ClientOutcomesSection } from '@/components/cms/client-outcomes-section';
import { DirectContactSection } from '@/components/cms/direct-contact-section';
import { PageSectionDto } from '@/lib/cms-types';
import { ScrollReveal } from '@/components/motion';
import { SubpageHero } from '@/components/ui/subpage-hero';
import { JsonLd, buildBreadcrumbsSchema, buildWebPageSchema } from '@/components/seo/json-ld';
import { getSiteUrl } from '@/lib/site-url';

export const revalidate = 60;

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug('contact');
  const seo = page?.seoMetadata;
  const resolvedTitle = seo?.metaTitle || 'Contact Us | Gypsym Technology';

  return {
    title: { absolute: resolvedTitle },
    description:
      seo?.metaDescription ||
      'Reach out to Gypsym Technology for Shopify Plus development, custom theme engineering, D2C strategy, and e-commerce partnerships. We respond within one business day.',
    openGraph: {
      title: seo?.ogTitle || resolvedTitle,
      description:
        seo?.ogDescription ||
        seo?.metaDescription ||
        'Start a conversation with our Shopify Plus engineers. Fast response, zero obligation.',
      images: seo?.ogImageUrl ? [{ url: seo.ogImageUrl }] : undefined,
    },
    robots: seo?.noIndex ? { index: false, follow: false } : undefined,
  };
}

const CONTACT_CREDENTIALS = [
  { label: 'Avg. Response Time', value: '< 4h', sub: 'Business hours' },
  { label: 'Projects Delivered', value: '120+', sub: 'Shopify Plus stores' },
  { label: 'Time Zones Covered', value: '12+', sub: 'Global availability' },
  { label: 'Dedicated Engineers', value: '25+', sub: 'Liquid, CRO & Theme leads' },
];

export default async function ContactPage() {
  const [page, homePage, contactSettings] = await Promise.all([
    getPageBySlug('contact'),
    getPageBySlug('home'),
    getContactSettings(),
  ]);

  const rawContactSection = page?.sections?.find(
    (s: any) =>
      s.componentType === 'CONTACT' ||
      s.sectionIdentifier === 'contact-form' ||
      s.sectionIdentifier === 'contact',
  );

  const rawHeroSection = page?.sections?.find(
    (s: any) =>
      s.componentType === 'HERO' ||
      s.sectionIdentifier === 'contact-hero'
  );
  const heroPayload = (rawHeroSection?.contentPayload as any) || {};

  const rawHomeContact = homePage?.sections?.find(
    (s: any) =>
      s.componentType === 'CONTACT' ||
      s.sectionIdentifier === 'contact-inquiry',
  );

  const rawOutcomesSection = page?.sections?.find(
    (s: any) =>
      s.componentType === 'CLIENT_OUTCOMES' ||
      s.componentType === 'STORE_OUTCOMES' ||
      s.sectionIdentifier === 'client-outcomes' ||
      s.sectionIdentifier === 'store-outcomes',
  );

  const rawDirectContactSection = page?.sections?.find(
    (s: any) =>
      s.componentType === 'DIRECT_CONTACT' ||
      s.componentType === 'DIRECT_CHANNELS' ||
      s.componentType === 'REACH_US_DIRECTLY' ||
      s.sectionIdentifier === 'direct-contact' ||
      s.sectionIdentifier === 'reach-us-directly' ||
      s.sectionIdentifier === 'direct-channels',
  );

  const globalContactDetails = {
    email: contactSettings.primaryEmail,
    phone: contactSettings.primaryPhone,
    address: contactSettings.headquartersAddress,
    officeHours: contactSettings.officeHours,
    socialLinks: (rawHomeContact?.contentPayload as any)?.globalContactDetails?.socialLinks || [],
  };

  const contactSectionToRender: PageSectionDto = rawContactSection || {
    id: 'contact-page-form-section',
    pageId: page?.id || 'contact',
    sectionIdentifier: 'contact-form',
    componentType: 'CONTACT',
    displayOrder: 2,
    isActive: true,
    contentPayload: {
      eyebrow: 'GET IN TOUCH',
      title: 'Start a Conversation With Our Team',
      titleHighlight: 'Conversation',
      description:
        'Whether you need a new Shopify Plus store, a custom theme, a CRO audit, or a long-term development partner — drop us a line. Our team reviews every inquiry personally.',
      contactInfo: {
        useGlobalDefaults: true,
        email: contactSettings.primaryEmail,
        phone: contactSettings.primaryPhone,
        address: contactSettings.headquartersAddress,
        officeHours: contactSettings.officeHours,
      },
      globalContactDetails,
      supportCard: {
        enabled: true,
        title: 'Free Shopify Store Audit',
        description:
          'Qualifying brands receive a complimentary 30-minute performance audit with one of our senior Shopify engineers — no strings attached.',
        ctaLabel: 'Claim your free audit',
        ctaUrl: '#contact-form',
      },
      form: {
        formTitle: 'Send Us a Message',
        formSubtitle: 'We respond to every message within one business day.',
        submitButtonText: 'Send Message',
        privacyNote: 'Your details are private. No spam, ever.',
        successTitle: 'Message Sent!',
        successMessage:
          'Thanks for reaching out. One of our Shopify engineers will be in touch within one business day.',
        fields: [
          {
            id: 'cf-name',
            name: 'fullName',
            label: 'Full Name',
            type: 'text',
            placeholder: 'Jane Smith',
            required: true,
            width: 'half',
          },
          {
            id: 'cf-email',
            name: 'email',
            label: 'Email Address',
            type: 'email',
            placeholder: 'jane@yourbrand.com',
            required: true,
            width: 'half',
          },
          {
            id: 'cf-company',
            name: 'companyName',
            label: 'Company / Brand Name',
            type: 'text',
            placeholder: 'Your Brand Inc.',
            required: false,
            width: 'half',
          },
          {
            id: 'cf-phone',
            name: 'phone',
            label: 'Phone Number',
            type: 'tel',
            placeholder: '+1 (555) 000-0000',
            required: false,
            width: 'half',
          },
          {
            id: 'cf-service',
            name: 'serviceInterest',
            label: 'Area of Interest',
            type: 'select',
            placeholder: 'Select a service...',
            required: false,
            options: [
              'New Shopify Plus Store',
              'Custom Theme Development',
              'Conversion Rate Optimisation',
              'Shopify Migration',
              'Ongoing Retainer Support',
              'Other / General Enquiry',
            ],
            width: 'full',
          },
          {
            id: 'cf-message',
            name: 'message',
            label: 'Tell Us About Your Project',
            type: 'textarea',
            placeholder:
              'Share a brief overview of your project, goals, or questions...',
            required: true,
            width: 'full',
          },
        ],
      },
    },
  };

  const breadcrumbSchema = buildBreadcrumbsSchema([
    { name: 'Home', item: '/' },
    { name: 'Contact Us', item: '/contact' },
  ]);

  const contactSchema = buildWebPageSchema({
    name: 'Contact Gypsym Technology',
    description: 'Reach out to Gypsym Technology for Shopify Plus development, custom theme engineering, D2C strategy, and e-commerce partnerships.',
    url: `${getSiteUrl()}/contact`,
    type: 'ContactPage',
  });

  return (
    <div className="w-full">
      <JsonLd data={breadcrumbSchema} />
      <JsonLd data={contactSchema} />
      <SubpageHero
        ariaLabel="Contact Hero"
        backgroundImageUrl={heroPayload.backgroundImage || heroPayload.heroBackgroundImage || heroPayload.backgroundImageUrl || "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2200&auto=format&fit=crop"}
        imageAlt="Gypsym Technology — Modern collaborative workspace"
        eyebrow={heroPayload.eyebrow || "Gypsym Technology · Get In Touch"}
        eyebrowBulletColor="bg-[#d9287c]"
        titlePrefix={heroPayload.title || "Let's Build Something"}
        titleHighlight={heroPayload.titleHighlight || "Remarkable"}
        titleSuffix={heroPayload.title ? (heroPayload.titleSuffix || undefined) : "Together"}
        description={heroPayload.description || "Whether you need a new Shopify Plus storefront, a performance overhaul, or a long-term engineering partner — our team is ready. Every message is read personally and replied to within one business day."}
        credentials={Array.isArray(heroPayload.credentials) && heroPayload.credentials.length > 0 ? heroPayload.credentials : CONTACT_CREDENTIALS}
        showHeroStrip={heroPayload.showHeroStrip !== undefined ? heroPayload.showHeroStrip : true}
        actions={
          <>
            <a
              href="#contact-form"
              className="inline-flex items-center px-6 sm:px-7 py-3 rounded-full bg-white text-neutral-950 font-semibold text-xs sm:text-sm hover:bg-neutral-100 hover:scale-105 transition-all shadow-xl shadow-black/20"
            >
              <span>Send Us a Message</span>
              <ArrowUpRight className="ml-1.5 h-3.5 w-3.5" />
            </a>
            <a
              href={`mailto:${contactSettings.primaryEmail}`}
              className="inline-flex items-center gap-2 px-5 sm:px-6 py-3 rounded-full bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/25 text-white font-medium text-xs sm:text-sm transition-all"
            >
              <Mail className="h-3.5 w-3.5" />
              <span>{contactSettings.primaryEmail}</span>
            </a>
          </>
        }
      />

      <div id="contact-form" className="w-full relative overflow-x-clip">
        <ScrollReveal direction="up" intensity="subtle" className="w-full">
          <ContactSection section={contactSectionToRender} contactSettings={contactSettings} />
        </ScrollReveal>
      </div>

      {/* ── 3. Or Reach Us Directly (Direct Channels) ── */}
      <div id="reach-us-directly" className="w-full relative overflow-x-clip">
        <ScrollReveal direction="up" intensity="subtle" className="w-full">
          <DirectContactSection
            section={rawDirectContactSection}
            payload={rawDirectContactSection?.contentPayload || contactSectionToRender?.contentPayload?.directChannels}
            contactSettings={contactSettings}
          />
        </ScrollReveal>
      </div>

      {/* ── 4. How Store Owners Like You Use Gypsym (Outcomes & Proof) ── */}
      <div id="client-outcomes" className="w-full relative overflow-x-clip">
        <ScrollReveal direction="up" intensity="subtle" className="w-full">
          <ClientOutcomesSection section={rawOutcomesSection} />
        </ScrollReveal>
      </div>
    </div>
  );
}