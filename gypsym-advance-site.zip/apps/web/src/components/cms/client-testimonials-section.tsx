'use client';

import * as React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { PageSectionDto, ClientTestimonialsPayload, VideoTestimonialDto, TextTestimonialDto } from '@/lib/cms-types';
import { renderTitleWithHighlight } from '@/lib/render-title-highlight';
import { Play, Pause, Volume2, VolumeX, Star, X, ArrowRight, CheckCircle2, ChevronLeft, ChevronRight, ChevronDown, ChevronUp } from 'lucide-react';
import { ScrollReveal, StaggerContainer, RevealItem, AnimatedCounter } from '@/components/motion';
import { parseVideoUrl } from '@/lib/video-url';

// ── Custom In-Canvas Video Player (Story / Reel agency style) ───────────────
interface CustomCanvasVideoPlayerProps {
  vid: VideoTestimonialDto;
  embedUrl: string;
  isDirectFile: boolean;
  clientName: string;
  loopVideos: boolean;
  onClose: () => void;
}

function CustomCanvasVideoPlayer({
  vid,
  embedUrl,
  isDirectFile,
  clientName,
  loopVideos,
  onClose,
}: CustomCanvasVideoPlayerProps) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const [isPaused, setIsPaused] = React.useState(false);
  const [isMuted, setIsMuted] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const [showCenterIcon, setShowCenterIcon] = React.useState(false);

  // Programmatic play on mount without native autoPlay attribute
  React.useEffect(() => {
    // Silence/pause any other video elements on the entire page
    const allVideos = document.querySelectorAll('video');
    allVideos.forEach((v) => {
      if (v !== videoRef.current && !v.paused) {
        v.pause();
      }
    });

    const v = videoRef.current;
    if (!v) return;
    const playPromise = v.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        setIsPaused(true);
      });
    }

    return () => {
      if (videoRef.current) {
        videoRef.current.pause();
      }
    };
  }, []);

  const togglePlay = (e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      const p = v.play();
      if (p !== undefined) {
        p.catch(() => {});
      }
      setIsPaused(false);
      setShowCenterIcon(true);
      setTimeout(() => setShowCenterIcon(false), 500);
    } else {
      v.pause();
      setIsPaused(true);
      setShowCenterIcon(true);
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setIsMuted(v.muted);
  };

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    const { currentTime, duration } = v;
    if (duration > 0) {
      setProgress((currentTime / duration) * 100);
    }
  };

  const handleVideoEnded = () => {
    setIsPaused(true);
    const v = videoRef.current;
    if (!loopVideos && v) {
      v.pause();
    }
  };

  if (!isDirectFile) {
    return (
      <div className="relative w-full h-full bg-black flex items-center justify-center">
        <iframe
          src={embedUrl}
          title={`Video testimonial - ${clientName}`}
          className="w-full h-full border-0 rounded-[28px]"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onClose();
          }}
          className="absolute top-3.5 right-3.5 z-30 p-2.5 rounded-full bg-black/70 hover:bg-black text-white hover:scale-110 active:scale-95 transition-all shadow-lg backdrop-blur-md cursor-pointer focus:outline-none"
          aria-label="Stop video playback and return to photo"
          title="Close video"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div
      className="relative w-full h-full bg-black flex items-center justify-center select-none group/player overflow-hidden rounded-[28px]"
      onClick={(e) => togglePlay(e)}
    >
      <video
        ref={videoRef}
        key={vid.id}
        src={embedUrl}
        playsInline
        loop={loopVideos}
        muted={isMuted}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleVideoEnded}
        onPlay={() => setIsPaused(false)}
        onPause={() => setIsPaused(true)}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          togglePlay(e);
        }}
        className="w-full h-full object-cover rounded-[28px] cursor-pointer"
      />

      {/* Top Floating Controls */}
      <div className="absolute top-3.5 left-3.5 right-3.5 z-20 flex items-center justify-between pointer-events-none">
        {/* Metric Badge */}
        {vid.metricHighlight ? (
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 text-neutral-900 backdrop-blur-md shadow-xs pointer-events-auto">
            {vid.metricHighlight}
          </span>
        ) : (
          <span />
        )}

        {/* Top-Right Dismiss / Close Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            const v = videoRef.current;
            if (v) v.pause();
            onClose();
          }}
          className="p-2.5 rounded-full bg-black/70 hover:bg-black text-white hover:scale-110 active:scale-95 transition-all shadow-lg backdrop-blur-md cursor-pointer pointer-events-auto focus:outline-none"
          aria-label="Stop video playback and return to photo"
          title="Close video"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Center Play/Pause Indicator (Clean White matching idle card when paused) */}
      {(isPaused || showCenterIcon) && (
        <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none">
          <div
            onClick={(e) => togglePlay(e)}
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white/95 text-neutral-900 flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-200 pointer-events-auto cursor-pointer"
            aria-label={isPaused ? 'Resume video' : 'Pause video'}
          >
            {isPaused ? (
              <Play className="w-6 h-6 sm:w-7 sm:h-7 fill-neutral-900 ml-1 text-neutral-900" />
            ) : (
              <Pause className="w-6 h-6 sm:w-7 sm:h-7 fill-neutral-900 text-neutral-900" />
            )}
          </div>
        </div>
      )}

      {/* Elegant Gradient Scrim for Bottom Information & Controls */}
      <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none z-10" />

      {/* Bottom Information & Sleek Action Buttons */}
      <div className="absolute bottom-3.5 left-4 right-4 z-20 flex items-end justify-between pointer-events-none">
        {/* Founder Info */}
        <div className="text-left text-white max-w-[65%]">
          <h3 className="text-sm sm:text-base font-bold drop-shadow-md leading-tight truncate">
            {clientName}
          </h3>
          <p className="text-[11px] sm:text-xs text-white/85 font-medium drop-shadow-sm truncate mt-0.5">
            {vid.company}
            {vid.location ? ` · ${vid.location}` : ''}
          </p>
        </div>

        {/* Play/Pause & Sound Buttons */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            type="button"
            onClick={(e) => togglePlay(e)}
            className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-white hover:scale-110 active:scale-95 transition-all shadow-md backdrop-blur-md cursor-pointer focus:outline-none"
            aria-label={isPaused ? 'Play' : 'Pause'}
            title={isPaused ? 'Play' : 'Pause'}
          >
            {isPaused ? (
              <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
            ) : (
              <Pause className="w-3.5 h-3.5 fill-white" />
            )}
          </button>
          <button
            type="button"
            onClick={(e) => toggleMute(e)}
            className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-white hover:scale-110 active:scale-95 transition-all shadow-md backdrop-blur-md cursor-pointer focus:outline-none"
            aria-label={isMuted ? 'Unmute' : 'Mute'}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? (
              <VolumeX className="w-3.5 h-3.5" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>

      {/* Ultra-Sleek Bottom Edge Animated Progress Bar */}
      <div className="absolute bottom-0 inset-x-0 h-1 bg-white/20 z-30">
        <div
          className="h-full bg-gradient-to-r from-[#d9127b] to-rose-400 transition-[width] duration-100 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}

interface ClientTestimonialsSectionProps {
  section: PageSectionDto;
}

export function ClientTestimonialsSection({ section }: ClientTestimonialsSectionProps) {
  const p = (section.contentPayload as ClientTestimonialsPayload) || {};

  const eyebrow = p.eyebrow;
  const title = p.title || '';
  const titleHighlight = p.titleHighlight;
  const description = p.description || '';
  const ratingSummary = p.ratingSummary;
  const bottomTrustBar = p.bottomTrustBar;
  const playOnHover = p.playOnHover ?? false;
  const loopVideos = p.loopVideos ?? false;

  const rawVideos: VideoTestimonialDto[] = Array.isArray(p.videoTestimonials) ? p.videoTestimonials : [];
  const videos = rawVideos
    .filter((v) => v && v.isActive !== false && (v as any).status !== 'DRAFT')
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const rawTestimonials: TextTestimonialDto[] = Array.isArray(p.textTestimonials) ? p.textTestimonials : [];
  const testimonials = rawTestimonials
    .filter((t) => t && t.isActive !== false && (t as any).status !== 'DRAFT')
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  // Separate featured testimonial from regular grid testimonials
  const featuredTestimonial = testimonials.find((t) => t.isFeatured) || testimonials[0];
  const gridTestimonials = featuredTestimonial
    ? testimonials.filter((t) => t.id !== featuredTestimonial.id)
    : testimonials;

  // State to expand more reviews (reference layout shows 1 featured + 12 grid cards = 13 total)
  const [showAllReviews, setShowAllReviews] = React.useState(false);
  const baseGridCount = 12;
  const displayedGridTestimonials = showAllReviews
    ? gridTestimonials
    : gridTestimonials.slice(0, baseGridCount);
  const remainingReviewsCount = Math.max(0, gridTestimonials.length - baseGridCount);
  const reviewPlural = remainingReviewsCount === 1 ? 'review' : 'reviews';

  // Mobile combined list (featured first, then grid reviews)
  const allMobileTestimonials = featuredTestimonial
    ? [featuredTestimonial, ...gridTestimonials]
    : testimonials;
  const displayedMobileTestimonials = showAllReviews
    ? allMobileTestimonials
    : allMobileTestimonials.slice(0, baseGridCount + 1);

  // In-canvas single active video playback state
  const [playingVideoId, setPlayingVideoId] = React.useState<string | null>(null);

  // Desktop hover preview video state
  const [hoveredVideoId, setHoveredVideoId] = React.useState<string | null>(null);

  // Track viewport so ONLY ONE <video> element ever mounts in the entire DOM
  const [isMobileViewport, setIsMobileViewport] = React.useState(false);

  React.useEffect(() => {
    const handleResize = () => {
      setIsMobileViewport(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Expanded text testimonials state ("Read more")
  const [expandedIds, setExpandedIds] = React.useState<Record<string, boolean>>({});

  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // ── Mobile Video Slider Controls ──────────────────────────────────────────
  const videoSliderRef = React.useRef<HTMLDivElement>(null);
  const [activeVideoSlide, setActiveVideoSlide] = React.useState(0);

  const handleVideoScroll = () => {
    if (!videoSliderRef.current) return;
    const el = videoSliderRef.current;
    const slideWidth = el.firstElementChild
      ? (el.firstElementChild as HTMLElement).offsetWidth + 16
      : el.clientWidth;
    const currentIdx = Math.round(el.scrollLeft / slideWidth);
    setActiveVideoSlide(Math.max(0, Math.min(videos.length - 1, currentIdx)));
  };

  const scrollVideoTo = (index: number) => {
    if (!videoSliderRef.current) return;
    const el = videoSliderRef.current;
    const slideWidth = el.firstElementChild
      ? (el.firstElementChild as HTMLElement).offsetWidth + 16
      : el.clientWidth;
    el.scrollTo({ left: index * slideWidth, behavior: 'smooth' });
    setActiveVideoSlide(index);
  };

  const scrollVideoPrev = () => {
    scrollVideoTo(Math.max(0, activeVideoSlide - 1));
  };

  const scrollVideoNext = () => {
    scrollVideoTo(Math.min(videos.length - 1, activeVideoSlide + 1));
  };

  // ── Mobile Text Reviews Slider Controls ────────────────────────────────────
  const textSliderRef = React.useRef<HTMLDivElement>(null);
  const [activeTextSlide, setActiveTextSlide] = React.useState(0);

  const handleTextScroll = () => {
    if (!textSliderRef.current) return;
    const el = textSliderRef.current;
    const slideWidth = el.firstElementChild
      ? (el.firstElementChild as HTMLElement).offsetWidth + 16
      : el.clientWidth;
    const currentIdx = Math.round(el.scrollLeft / slideWidth);
    setActiveTextSlide(Math.max(0, Math.min(displayedMobileTestimonials.length - 1, currentIdx)));
  };

  const scrollTextTo = (index: number) => {
    if (!textSliderRef.current) return;
    const el = textSliderRef.current;
    const slideWidth = el.firstElementChild
      ? (el.firstElementChild as HTMLElement).offsetWidth + 16
      : el.clientWidth;
    el.scrollTo({ left: index * slideWidth, behavior: 'smooth' });
    setActiveTextSlide(index);
  };

  const scrollTextPrev = () => {
    scrollTextTo(Math.max(0, activeTextSlide - 1));
  };

  const scrollTextNext = () => {
    scrollTextTo(Math.min(displayedMobileTestimonials.length - 1, activeTextSlide + 1));
  };

  // Keyboard close for active in-canvas video (ESC)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setPlayingVideoId(null);
      }
    };
    if (playingVideoId) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playingVideoId]);

  return (
    <div
      id={section.sectionIdentifier || 'client-testimonials'}
      aria-labelledby={`heading-${section.id}`}
      className="w-full py-8 sm:py-10 md:py-12 transition-colors"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 md:px-8 space-y-8 sm:space-y-10">
        {/* ── SECTION HEADER & RATING SUMMARY ─────────────────────────────────── */}
        <ScrollReveal direction="up">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            {/* Left Column: Eyebrow, Main Headline & Description */}
            <div className="max-w-3xl space-y-3.5 text-left">
              {eyebrow && (
                <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-[#d9287c] uppercase">
                  <span className="inline-block w-2 h-2 rounded-full bg-[#d9287c]" />
                  <span>{eyebrow}</span>
                </div>
              )}

              <h2
                id={`heading-${section.id}`}
                className="text-4xl sm:text-5xl lg:text-[54px] font-bold tracking-tight text-neutral-900 dark:text-white leading-[1.12] whitespace-pre-line"
              >
                {renderTitleWithHighlight(title, titleHighlight)}
              </h2>

              {description && (
                <p className="text-base sm:text-lg text-neutral-700 dark:text-neutral-300 leading-relaxed max-w-2xl pt-0.5">
                  {description}
                </p>
              )}
            </div>

            {/* Right Column: Dynamic Rating Summary Badge */}
            {ratingSummary && ratingSummary.enabled !== false && (
              <div className="shrink-0 self-start md:self-auto">
                <div className="bg-white dark:bg-card border border-neutral-200/80 dark:border-border rounded-2xl p-4 sm:p-5 shadow-xs flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-3xl sm:text-4xl font-extrabold text-neutral-900 dark:text-white tracking-tight">
                    <AnimatedCounter
                      value={ratingSummary.ratingValue}
                      decimals={1}
                      duration={1.6}
                    />
                    <Star className="w-6 h-6 fill-amber-400 text-amber-400 shrink-0" aria-hidden="true" />
                  </div>
                  <div className="border-l border-neutral-200 dark:border-neutral-800 pl-3.5 text-left space-y-0.5">
                    <span className="text-xs sm:text-sm font-semibold text-neutral-800 dark:text-neutral-200 block leading-tight">
                      {ratingSummary.reviewCountText}
                    </span>
                    {ratingSummary.badgeText && (
                      <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block">
                        {ratingSummary.badgeText}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollReveal>

        {/* ── VIDEO TESTIMONIALS ──────────────────────────────────────────────── */}
        {videos.length > 0 && (() => {
          // ── Render Video Card (In-Canvas Playback & Single-Active Controller) ───────
          const renderVideoCard = (vid: VideoTestimonialDto, isMobile = false) => {
            // Strictly guard so only the active viewport's card mounts the <video> element
            const isPlaying =
              playingVideoId === vid.id &&
              (isMobile ? isMobileViewport : !isMobileViewport);
            const isHovered = playOnHover && !isMobile && hoveredVideoId === vid.id && !isPlaying;
            const clientName = vid.clientName || (vid as any).name || 'Founder';
            const parsed = parseVideoUrl(vid.videoUrl);

            return (
              <div
                className={`group relative aspect-[3/4] rounded-[28px] overflow-hidden bg-neutral-900 border border-neutral-200/70 dark:border-neutral-800 transition-all duration-300 ${
                  isMobile ? 'w-[82vw] max-w-[310px] shrink-0 snap-center' : ''
                } ${
                  isPlaying
                    ? 'ring-1 ring-black/10 dark:ring-white/20 shadow-xl'
                    : 'cursor-pointer hover:shadow-lg hover:-translate-y-0.5'
                }`}
                onMouseEnter={() => {
                  if (playOnHover && !isMobile) setHoveredVideoId(vid.id);
                }}
                onMouseLeave={() => {
                  if (playOnHover && !isMobile) setHoveredVideoId(null);
                }}
                onClick={() => {
                  if (!isPlaying && vid.videoUrl) {
                    setPlayingVideoId(vid.id);
                  }
                }}
              >
                {isPlaying && parsed ? (
                  /* Custom In-Canvas Story/Reel Video Player */
                  <CustomCanvasVideoPlayer
                    vid={vid}
                    embedUrl={parsed.embedUrl}
                    isDirectFile={parsed.isDirectFile}
                    clientName={clientName}
                    loopVideos={loopVideos}
                    onClose={() => setPlayingVideoId(null)}
                  />
                ) : (
                  /* Idle Founder Card with Photo Thumbnail, Badges & Centered Play Button */
                  <>
                    {/* Hover Video Preview or Photo Thumbnail */}
                    {isHovered && parsed?.isDirectFile ? (
                      <video
                        src={parsed.embedUrl}
                        autoPlay
                        muted
                        loop
                        playsInline
                        className="w-full h-full object-cover select-none"
                      />
                    ) : vid.thumbnailUrl ? (
                      <Image
                        src={vid.thumbnailUrl}
                        alt={`${clientName} - ${vid.company}`}
                        fill
                        sizes={isMobile ? '82vw' : '(max-width: 768px) 100vw, 33vw'}
                        className="object-cover transition-transform duration-500 group-hover:scale-105 select-none"
                      />
                    ) : (
                      <div className="w-full h-full bg-neutral-900 flex items-center justify-center text-neutral-500 text-xs font-mono">
                        No preview
                      </div>
                    )}

                    {/* Top Metric Highlight Badge (Timing/Duration hidden per design request) */}
                    {vid.metricHighlight && (
                      <div className="absolute top-3.5 left-3.5 z-10 flex items-center gap-1.5 pointer-events-none">
                        <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 dark:bg-black/85 text-neutral-900 dark:text-white backdrop-blur-md shadow-xs">
                          {vid.metricHighlight}
                        </span>
                      </div>
                    )}

                    {/* Subtle Gradient Scrim */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />

                    {/* Centered Play Button */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div
                        className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white/95 text-neutral-900 flex items-center justify-center shadow-xl group-hover:scale-110 group-hover:bg-white active:scale-95 transition-all duration-200"
                        aria-label={`Play video testimonial from ${clientName}`}
                      >
                        <Play className="w-6 h-6 sm:w-7 sm:h-7 fill-neutral-900 ml-1 text-neutral-900" aria-hidden="true" />
                      </div>
                    </div>

                    {/* Bottom Card Content: Client Name & Company */}
                    <div className="absolute bottom-5 left-5 right-5 text-left text-white pointer-events-none">
                      <h3 className="text-base sm:text-lg font-bold drop-shadow-md leading-tight">
                        {clientName}
                      </h3>
                      <p className="text-xs sm:text-sm text-white/85 font-medium drop-shadow-sm mt-0.5">
                        {vid.company}
                        {vid.location ? ` · ${vid.location}` : ''}
                      </p>
                    </div>
                  </>
                )}
              </div>
            );
          };

          return (
            <div>
              {/* DESKTOP VIEW: 3-Card Grid */}
              <StaggerContainer preset="fast" className="hidden md:grid md:grid-cols-3 gap-5 sm:gap-6">
                {videos.map((vid) => (
                  <RevealItem key={vid.id}>
                    {renderVideoCard(vid, false)}
                  </RevealItem>
                ))}
              </StaggerContainer>

              {/* MOBILE VIEW: Touch Swipeable Horizontal Slider */}
              <div className="block md:hidden space-y-3">
                <div
                  ref={videoSliderRef}
                  onScroll={handleVideoScroll}
                  className="flex overflow-x-auto snap-x snap-mandatory [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden gap-4 -mx-4 px-4 pb-2 pt-1 scroll-smooth"
                >
                  {videos.map((vid) => (
                    <React.Fragment key={vid.id}>
                      {renderVideoCard(vid, true)}
                    </React.Fragment>
                  ))}
                </div>

                {/* Mobile Video Slider Controls: Prev/Next Buttons + Dot Pagination */}
                <div className="flex items-center justify-between pt-1 px-1">
                  {/* Dots indicator */}
                  <div className="flex items-center gap-1.5">
                    {videos.map((_, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => scrollVideoTo(i)}
                        className={`h-2 rounded-full transition-all duration-300 ${
                          activeVideoSlide === i
                            ? 'w-6 bg-[#d9287c]'
                            : 'w-2 bg-neutral-300 dark:bg-neutral-700'
                        }`}
                        aria-label={`Go to video slide ${i + 1}`}
                      />
                    ))}
                  </div>

                  {/* Arrow Navigation */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={scrollVideoPrev}
                      disabled={activeVideoSlide === 0}
                      className="w-9 h-9 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-center shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-colors"
                      aria-label="Previous video testimonial"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={scrollVideoNext}
                      disabled={activeVideoSlide >= videos.length - 1}
                      className="w-9 h-9 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-center shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-colors"
                      aria-label="Next video testimonial"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* ── TEXT TESTIMONIALS: FEATURED + GRID ─────────────────────────────── */}
        {testimonials.length > 0 && (
          <ScrollReveal direction="up" delay={100}>
            <div>
              {/* DESKTOP VIEW: Unified 4-Column Bento Grid matching reference */}
            <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 items-stretch">
              {/* Featured Testimonial Card (Spans 2 columns and 2 rows on lg screen) */}
              {featuredTestimonial && (
                <div className="md:col-span-2 md:row-span-2 lg:col-span-2 lg:row-span-2 bg-[#121212] dark:bg-neutral-900 text-white rounded-[24px] sm:rounded-[28px] p-6 sm:p-8 md:p-9 border border-neutral-800 shadow-md flex flex-col justify-between space-y-6">
                  {/* Top: Repeat Client Badge on top right */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-amber-400">
                      {Array.from({ length: featuredTestimonial.rating || 5 }).map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400" aria-hidden="true" />
                      ))}
                    </div>

                    {featuredTestimonial.isRepeatClient && (
                      <span className="text-[11px] font-semibold text-[#facc15] bg-[#ca8a04]/15 border border-[#ca8a04]/30 px-3 py-1 rounded-full uppercase tracking-wider">
                        Repeat Client
                      </span>
                    )}
                  </div>

                  {/* Main Quote Content */}
                  <blockquote className="text-base sm:text-lg lg:text-xl font-medium sm:font-semibold text-neutral-100 leading-relaxed text-left">
                    &ldquo;{featuredTestimonial.content || featuredTestimonial.quote}&rdquo;
                  </blockquote>

                  {/* Author Info */}
                  <div className="flex items-center gap-3.5 pt-2 border-t border-neutral-800/80">
                    {featuredTestimonial.avatarUrl ? (
                      <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden shrink-0 border border-neutral-700">
                        <Image
                          src={featuredTestimonial.avatarUrl}
                          alt={featuredTestimonial.clientName || (featuredTestimonial as any).name || 'Client'}
                          fill
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-neutral-800 flex items-center justify-center font-bold text-sm text-neutral-300 border border-neutral-700">
                        {(featuredTestimonial.clientName || (featuredTestimonial as any).name || 'C').charAt(0)}
                      </div>
                    )}
                    <div className="text-left truncate">
                      <span className="font-bold text-white text-sm sm:text-base block truncate">
                        {featuredTestimonial.clientName || (featuredTestimonial as any).name || 'Verified Client'}
                      </span>
                      <span className="text-xs text-neutral-400 block truncate mt-0.5">
                        {featuredTestimonial.role ? `${featuredTestimonial.role}, ` : ''}
                        {featuredTestimonial.company}
                        {featuredTestimonial.location ? ` · ${featuredTestimonial.location}` : ''}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Grid of Other Testimonials */}
              {displayedGridTestimonials.map((item) => {
                const isExpanded = !!expandedIds[item.id];
                const reviewText = item.content || item.quote || '';
                const shouldTruncate = reviewText.length > 180;
                const displayContent =
                  shouldTruncate && !isExpanded
                    ? `${reviewText.slice(0, 180)}…`
                    : reviewText;
                const authorName = item.clientName || (item as any).name || 'Verified Client';

                return (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-card border border-neutral-200/80 dark:border-border rounded-[22px] p-5 sm:p-5.5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between space-y-3.5 min-h-[200px]"
                  >
                    {/* Top Row: Stars + Repeat Client Badge */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1 text-amber-400" aria-label={`Rated ${item.rating || 5} out of 5`}>
                        {Array.from({ length: item.rating || 5 }).map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />
                        ))}
                      </div>

                      {item.isRepeatClient && (
                        <span className="text-[10px] font-semibold text-[#d9127b] bg-[#fdf2f8] dark:bg-pink-950/50 dark:text-pink-300 border border-[#fbcfe8] dark:border-pink-800/40 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                          Repeat Client
                        </span>
                      )}
                    </div>

                    {/* Content with Read More toggle */}
                    <div className="text-left flex-1">
                      <p className="text-xs sm:text-[13px] text-neutral-700 dark:text-neutral-300 leading-relaxed">
                        &ldquo;{displayContent}&rdquo;
                      </p>
                      {shouldTruncate && (
                        <button
                          type="button"
                          onClick={() => toggleExpand(item.id)}
                          className="text-xs font-semibold text-[#d9127b] hover:underline mt-1.5 inline-block cursor-pointer"
                        >
                          {isExpanded ? 'Read less' : 'Read more'}
                        </button>
                      )}
                    </div>

                    {/* Author row */}
                    <div className="flex items-center gap-3 pt-2 border-t border-neutral-100 dark:border-neutral-800/60">
                      {item.avatarUrl ? (
                        <div className="relative w-8 h-8 sm:w-8.5 sm:h-8.5 rounded-full overflow-hidden shrink-0 border border-neutral-200 dark:border-neutral-700">
                          <Image
                            src={item.avatarUrl}
                            alt={authorName}
                            fill
                            className="object-cover"
                          />
                        </div>
                      ) : (
                        <div className="w-8 h-8 sm:w-8.5 sm:h-8.5 rounded-full bg-pink-100 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 flex items-center justify-center font-bold text-xs shrink-0">
                          {authorName.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="text-left truncate">
                        <span className="text-xs sm:text-[13px] font-bold text-neutral-900 dark:text-white block truncate">
                          {authorName}
                        </span>
                        <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block truncate">
                          {item.company}
                          {item.location ? ` · ${item.location}` : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* See More button: Spans full width if remainingReviewsCount > 0 */}
              {remainingReviewsCount > 0 && (
                <div className="col-span-full flex justify-center pt-4">
                  <button
                    type="button"
                    onClick={() => setShowAllReviews(!showAllReviews)}
                    className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full bg-white dark:bg-card border border-neutral-200/90 dark:border-neutral-800 text-xs sm:text-sm font-bold text-neutral-800 dark:text-neutral-200 shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 hover:shadow-xs transition-all cursor-pointer group"
                  >
                    <span>{showAllReviews ? 'Show fewer reviews' : `See ${remainingReviewsCount} more text ${reviewPlural}`}</span>
                    {showAllReviews ? (
                      <ChevronUp className="w-4 h-4 text-neutral-500 group-hover:text-neutral-700 dark:group-hover:text-neutral-300 transition-transform" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-neutral-500 group-hover:text-neutral-700 dark:group-hover:text-neutral-300 transition-transform" />
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* MOBILE VIEW: Touch Swipeable Horizontal Slider */}
            <div className="block lg:hidden space-y-3">
              <div
                ref={textSliderRef}
                onScroll={handleTextScroll}
                className="flex overflow-x-auto snap-x snap-mandatory [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden gap-4 -mx-4 px-4 pb-2 pt-1 scroll-smooth"
              >
                {displayedMobileTestimonials.map((item, idx) => {
                  const isFeaturedCard = idx === 0 && item.id === featuredTestimonial?.id;
                  const isExpanded = !!expandedIds[item.id];
                  const reviewText = item.content || item.quote || '';
                  const shouldTruncate = reviewText.length > 180;
                  const displayContent =
                    shouldTruncate && !isExpanded
                      ? `${reviewText.slice(0, 180)}…`
                      : reviewText;
                  const authorName = item.clientName || (item as any).name || 'Verified Client';

                  if (isFeaturedCard) {
                    return (
                      <div
                        key={item.id}
                        className="w-[88vw] max-w-[340px] shrink-0 snap-center bg-neutral-950 dark:bg-neutral-900 text-white rounded-[28px] p-6 border border-neutral-800 shadow-md flex flex-col justify-between space-y-4 min-h-[350px]"
                      >
                        {/* Top: Stars + Repeat Client Badge */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 text-amber-400">
                            {Array.from({ length: item.rating || 5 }).map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-amber-400" aria-hidden="true" />
                            ))}
                          </div>

                          {item.isRepeatClient && (
                            <span className="text-[10px] font-bold text-amber-300 bg-amber-400/15 border border-amber-400/30 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                              Repeat Client
                            </span>
                          )}
                        </div>

                        {/* Quote Content */}
                        <blockquote className="text-sm font-normal text-neutral-100 leading-relaxed text-left">
                          &ldquo;{reviewText}&rdquo;
                        </blockquote>

                        {/* Author */}
                        <div className="flex items-center gap-3 pt-2 border-t border-neutral-800/80">
                          {item.avatarUrl ? (
                            <div className="relative w-10 h-10 rounded-full overflow-hidden shrink-0 border border-neutral-700">
                              <Image
                                src={item.avatarUrl}
                                alt={authorName}
                                fill
                                className="object-cover"
                              />
                            </div>
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center font-bold text-xs text-neutral-300 border border-neutral-700">
                              {authorName.charAt(0)}
                            </div>
                          )}
                          <div className="text-left truncate">
                            <span className="font-bold text-white text-sm block truncate">
                              {authorName}
                            </span>
                            <span className="text-[11px] text-neutral-400 block truncate">
                              {item.role ? `${item.role}, ` : ''}
                              {item.company}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={item.id}
                      className="w-[88vw] max-w-[340px] shrink-0 snap-center bg-white dark:bg-card border border-neutral-200/80 dark:border-border rounded-[24px] p-6 shadow-2xs flex flex-col justify-between space-y-4 min-h-[350px]"
                    >
                      {/* Top: Stars + Repeat Client Badge */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1 text-amber-400">
                          {Array.from({ length: item.rating || 5 }).map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />
                          ))}
                        </div>

                        {item.isRepeatClient && (
                          <span className="text-[10px] font-bold text-fuchsia-700 bg-fuchsia-50 dark:bg-fuchsia-950/50 dark:text-fuchsia-300 border border-fuchsia-100 dark:border-fuchsia-800/60 px-2 py-0.5 rounded-full uppercase tracking-wider">
                            Repeat Client
                          </span>
                        )}
                      </div>

                      {/* Content with Read More toggle */}
                      <div className="text-left flex-1">
                        <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                          &ldquo;{displayContent}&rdquo;
                        </p>
                        {shouldTruncate && (
                          <button
                            type="button"
                            onClick={() => toggleExpand(item.id)}
                            className="text-xs font-semibold text-primary hover:underline mt-1.5 inline-block cursor-pointer"
                          >
                            {isExpanded ? 'Read less' : 'Read more'}
                          </button>
                        )}
                      </div>

                      {/* Author */}
                      <div className="flex items-center gap-3 pt-2 border-t border-neutral-100 dark:border-neutral-800/60">
                        {item.avatarUrl ? (
                          <div className="relative w-8 h-8 rounded-full overflow-hidden shrink-0 border border-neutral-200 dark:border-neutral-700">
                            <Image
                              src={item.avatarUrl}
                              alt={authorName}
                              fill
                              className="object-cover"
                            />
                          </div>
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 flex items-center justify-center font-bold text-xs">
                            {authorName.charAt(0)}
                          </div>
                        )}
                        <div className="text-left truncate">
                          <span className="text-xs font-bold text-neutral-900 dark:text-white block truncate">
                            {authorName}
                          </span>
                          <span className="text-[11px] text-neutral-500 dark:text-neutral-400 block truncate">
                            {item.company}
                            {item.location ? ` · ${item.location}` : ''}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Mobile Text Reviews Controls: Prev/Next Buttons + Dot Pagination */}
              <div className="flex items-center justify-between pt-1 px-1">
                {/* Dots indicator */}
                <div className="flex items-center gap-1.5 overflow-hidden max-w-[200px]">
                  {displayedMobileTestimonials.map((_, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => scrollTextTo(i)}
                      className={`h-2 rounded-full transition-all duration-300 shrink-0 ${
                        activeTextSlide === i
                          ? 'w-6 bg-[#d9287c]'
                          : 'w-2 bg-neutral-300 dark:bg-neutral-700'
                      }`}
                      aria-label={`Go to review slide ${i + 1}`}
                    />
                  ))}
                </div>

                {/* Arrow Navigation */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={scrollTextPrev}
                    disabled={activeTextSlide === 0}
                    className="w-9 h-9 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-center shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-colors"
                    aria-label="Previous client review"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={scrollTextNext}
                    disabled={activeTextSlide >= displayedMobileTestimonials.length - 1}
                    className="w-9 h-9 rounded-full bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center justify-center shadow-xs disabled:opacity-30 disabled:pointer-events-none transition-colors"
                    aria-label="Next client review"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Mobile "See 9 more text reviews" toggle */}
              {remainingReviewsCount > 0 && (
                <div className="flex justify-center pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAllReviews(!showAllReviews)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white dark:bg-card border border-neutral-200/90 dark:border-neutral-800 text-xs font-bold text-neutral-800 dark:text-neutral-200 shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-800 hover:border-neutral-300 transition-all cursor-pointer group"
                  >
                    <span>{showAllReviews ? 'Show fewer reviews' : `See ${remainingReviewsCount} more text ${reviewPlural}`}</span>
                    {showAllReviews ? (
                      <ChevronUp className="w-3.5 h-3.5 text-neutral-500" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5 text-neutral-500" />
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
        </ScrollReveal>
        )}

        {/* ── BOTTOM TRUST & CTA BAR ─────────────────────────────────────────── */}
        {bottomTrustBar && bottomTrustBar.enabled !== false && (() => {
          const rawStatements = bottomTrustBar.trustStatements || '';
          const statementList = rawStatements.includes('·')
            ? rawStatements.split('·').map((s) => s.trim()).filter(Boolean)
            : [rawStatements];

          return (
            <ScrollReveal direction="up" delay={150}>
              <div className="rounded-[20px] sm:rounded-[28px] bg-[#fcf2f6] dark:bg-pink-950/30 border border-[#fae2ec] dark:border-pink-900/40 px-4 sm:px-8 py-4 sm:py-5 flex flex-col sm:flex-row items-center justify-between gap-3.5 sm:gap-4">
                {/* Responsive Statements List */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-3 sm:gap-x-4 gap-y-2 text-xs sm:text-sm font-semibold text-neutral-800 dark:text-neutral-200 text-center sm:text-left">
                  {statementList.map((stmt, idx) => (
                    <div key={idx} className="inline-flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#d9127b] shrink-0" aria-hidden="true" />
                      <span>{stmt}</span>
                      {idx < statementList.length - 1 && (
                        <span className="hidden sm:inline-block text-neutral-300 dark:text-neutral-700 ml-2" aria-hidden="true">
                          ·
                        </span>
                      )}
                    </div>
                  ))}
                </div>

                {bottomTrustBar.ctaLabel && (
                  <Link
                    href={bottomTrustBar.ctaUrl || '#contact'}
                    className="shrink-0 inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#d9127b] hover:text-[#b00e63] dark:text-pink-400 hover:underline transition-colors mt-0.5 sm:mt-0"
                  >
                    <span>{bottomTrustBar.ctaLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </Link>
                )}
              </div>
            </ScrollReveal>
          );
        })()}
      </div>
    </div>
  );
}
