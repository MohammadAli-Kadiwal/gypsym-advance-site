import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { PortfolioService } from './portfolio.service';
import { AuthGuard } from '../../common/guards/auth.guard';

@Controller('portfolio')
export class PortfolioController {
  constructor(private readonly portfolioService: PortfolioService) {}

  // ─── Public Endpoints ────────────────────────────────────────────────────────

  @Get()
  async getProjects(@Query() query: any) {
    return this.portfolioService.getProjects(query);
  }

  @Get('categories')
  async getCategories() {
    return this.portfolioService.getCategories();
  }

  // ─── Admin Listing Endpoints ─────────────────────────────────────────────────

  @Get('admin/categories')
  @UseGuards(AuthGuard)
  async getAllCategoriesForAdmin() {
    return this.portfolioService.getAllCategoriesForAdmin();
  }

  @Get('admin/projects')
  @UseGuards(AuthGuard)
  async getAllProjectsForAdmin() {
    return this.portfolioService.getAllProjectsForAdmin();
  }

  // ─── Category Admin CRUD ─────────────────────────────────────────────────────

  @Post('categories')
  @UseGuards(AuthGuard)
  async createCategory(@Body() body: any) {
    return this.portfolioService.createCategory(body);
  }

  @Put('categories/reorder')
  @UseGuards(AuthGuard)
  async reorderCategories(@Body() body: { items: Array<{ id: string; displayOrder: number }> }) {
    await this.portfolioService.reorderCategories(body.items);
    return { success: true };
  }

  @Put('categories/:id')
  @UseGuards(AuthGuard)
  async updateCategory(@Param('id') id: string, @Body() body: any) {
    return this.portfolioService.updateCategory(id, body);
  }

  @Post('categories/bulk-delete')
  @UseGuards(AuthGuard)
  async bulkDeleteCategories(@Body() body: { ids: string[] }) {
    return this.portfolioService.bulkDeleteCategories(body.ids);
  }

  @Delete('categories/:id')
  @UseGuards(AuthGuard)
  async deleteCategory(@Param('id') id: string) {
    await this.portfolioService.deleteCategory(id);
    return { success: true };
  }

  // ─── Project Detail & CRUD ───────────────────────────────────────────────────

  @Post('bulk-delete')
  @UseGuards(AuthGuard)
  async bulkDeleteProjects(@Body() body: { ids: string[] }) {
    return this.portfolioService.bulkDeleteProjects(body.ids);
  }

  @Put('reorder')
  @UseGuards(AuthGuard)
  async reorderProjects(@Body() body: { items: Array<{ id: string; displayOrder: number }> }) {
    await this.portfolioService.reorderProjects(body.items);
    return { success: true };
  }

  @Get(':slug')
  async getProjectBySlug(@Param('slug') slug: string) {
    return this.portfolioService.getProjectBySlug(slug);
  }

  @Post()
  @UseGuards(AuthGuard)
  async createProject(@Body() body: any) {
    return this.portfolioService.createProject(body);
  }

  @Put(':id')
  @UseGuards(AuthGuard)
  async updateProject(@Param('id') id: string, @Body() body: any) {
    return this.portfolioService.updateProject(id, body);
  }

  @Delete(':id')
  @UseGuards(AuthGuard)
  async deleteProject(@Param('id') id: string) {
    await this.portfolioService.deleteProject(id);
    return { success: true };
  }
}
